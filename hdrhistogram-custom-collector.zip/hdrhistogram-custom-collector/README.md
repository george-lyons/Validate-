# HdrHistogram + custom Prometheus collector

A minimal low-latency design for strategy-thread latency metrics:

- one `SingleWriterRecorder` per strategy/thread
- hot path only calls `record(...)` or `recordWithExpectedInterval(...)`
- one publisher thread snapshots interval histograms periodically
- publisher computes exported values off the hot path
- Prometheus scrape callbacks read only the latest published snapshot

## Why this shape

This keeps the strategy-thread path very small:

```java
long start = System.nanoTime();
strategy.run();
strategyLatency.record(System.nanoTime() - start);
```

There is:

- no Micrometer timer on the hot path
- no custom histogram implementation
- no ring buffer for histogram handoff
- no histogram traversal during scrape

## Main classes

- `StrategyLatency`
  - owns one `SingleWriterRecorder`
  - hot-path recording
  - exposes `snapshotInterval()`

- `LatencyPublisher`
  - single background publisher thread
  - snapshots all strategies
  - computes configured percentiles, max, mean, count
  - publishes with one volatile flip

- `PrometheusLatencyMetrics`
  - registers scrape callbacks
  - reads only the latest published values

- `Percentiles`
  - immutable percentile configuration

## Metrics exposed

Using metric prefix `algo_strategy_latency`, the example exposes:

- `algo_strategy_latency_ns{strategy="maker",percentile="50"}`
- `algo_strategy_latency_ns{strategy="maker",percentile="95"}`
- `algo_strategy_latency_ns{strategy="maker",percentile="99"}`
- `algo_strategy_latency_ns_max{strategy="maker"}`
- `algo_strategy_latency_ns_mean{strategy="maker"}`
- `algo_strategy_latency_interval_count{strategy="maker"}`

## Design notes

- Scrape-visible state is double-buffered.
- One volatile `activeSnapshotIndex` publishes a complete interval snapshot.
- Histogram walking happens on the publisher thread, not on scrape.
- `SingleWriterRecorder` is used because the intended ownership is one strategy / one hot thread.

## Example

Run:

```bash
mvn compile exec:java
```

Then scrape:

```bash
curl http://localhost:9400/metrics
```

## How to wire this into your platform

- Create one `StrategyLatency` per strategy / owning thread.
- In the strategy thread, record elapsed nanos.
- Start one `LatencyPublisher` for the strategy set.
- Register `PrometheusLatencyMetrics` once at startup.
- Choose a publish cadence such as 1 second.

## When this design is a good fit

This is a good fit when:

- hot-path control matters more than Prometheus-native histogram aggregation
- you mainly want per-strategy p50 / p95 / p99 / max / count visibility
- you want a simple, explicit handoff model

## Tradeoff

You are exposing precomputed interval metrics, not a native Prometheus histogram bucket series.

That means:

- simpler hot path
- simpler publisher model
- less flexible downstream histogram aggregation than native Prometheus histograms

For a bank algo platform, that can still be the right trade if the main concern is keeping instrumentation predictable and cheap.
