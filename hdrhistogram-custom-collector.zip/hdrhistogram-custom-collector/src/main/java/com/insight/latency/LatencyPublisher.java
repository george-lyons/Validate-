package com.insight.latency;

import org.HdrHistogram.Histogram;

import java.util.Objects;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;

/**
 * Single background publisher:
 * - snapshots each strategy's interval histogram
 * - computes selected exported values
 * - flips one volatile index to publish the completed snapshot
 */
public final class LatencyPublisher implements AutoCloseable {
    private final StrategyLatency[] strategies;
    private final Percentiles percentiles;
    private final PublishedLatencySnapshot[] snapshots;
    private final ScheduledExecutorService scheduler;
    private volatile int activeSnapshotIndex;

    public LatencyPublisher(
            final StrategyLatency[] strategies,
            final Percentiles percentiles,
            final long publishInterval,
            final TimeUnit publishIntervalUnit,
            final String threadName) {

        this.strategies = Objects.requireNonNull(strategies, "strategies");
        this.percentiles = Objects.requireNonNull(percentiles, "percentiles");
        this.snapshots = new PublishedLatencySnapshot[] {
                new PublishedLatencySnapshot(strategies.length, percentiles.size()),
                new PublishedLatencySnapshot(strategies.length, percentiles.size())
        };
        this.activeSnapshotIndex = 0;
        this.scheduler = Executors.newSingleThreadScheduledExecutor(new NamedDaemonThreadFactory(threadName));
        this.publishInterval = publishInterval;
        this.publishIntervalUnit = Objects.requireNonNull(publishIntervalUnit, "publishIntervalUnit");
    }

    private final long publishInterval;
    private final TimeUnit publishIntervalUnit;

    public void start() {
        scheduler.scheduleAtFixedRate(this::safePublish, publishInterval, publishInterval, publishIntervalUnit);
    }

    public void publishNow() {
        safePublish();
    }

    public long percentileValue(final int strategyIndex, final int percentileIndex) {
        return snapshots[activeSnapshotIndex].percentileValues[strategyIndex][percentileIndex];
    }

    public long maxValue(final int strategyIndex) {
        return snapshots[activeSnapshotIndex].maxValues[strategyIndex];
    }

    public long meanValue(final int strategyIndex) {
        return snapshots[activeSnapshotIndex].meanValues[strategyIndex];
    }

    public long countValue(final int strategyIndex) {
        return snapshots[activeSnapshotIndex].counts[strategyIndex];
    }

    @Override
    public void close() {
        scheduler.shutdownNow();
    }

    private void safePublish() {
        try {
            publish();
        } catch (final Throwable t) {
            t.printStackTrace(System.err);
        }
    }

    private void publish() {
        final int nextIndex = 1 - activeSnapshotIndex;
        final PublishedLatencySnapshot target = snapshots[nextIndex];

        for (int strategyIndex = 0; strategyIndex < strategies.length; strategyIndex++) {
            final Histogram interval = strategies[strategyIndex].snapshotInterval();
            final long count = interval.getTotalCount();

            if (count == 0L) {
                target.clearStrategy(strategyIndex);
                continue;
            }

            for (int percentileIndex = 0; percentileIndex < percentiles.size(); percentileIndex++) {
                target.percentileValues[strategyIndex][percentileIndex] =
                        interval.getValueAtPercentile(percentiles.value(percentileIndex));
            }

            target.maxValues[strategyIndex] = interval.getMaxValue();
            target.meanValues[strategyIndex] = (long) interval.getMean();
            target.counts[strategyIndex] = count;
        }

        activeSnapshotIndex = nextIndex;
    }

    private static final class NamedDaemonThreadFactory implements ThreadFactory {
        private final String threadName;

        private NamedDaemonThreadFactory(final String threadName) {
            this.threadName = (threadName == null || threadName.isBlank()) ? "latency-publisher" : threadName;
        }

        @Override
        public Thread newThread(final Runnable r) {
            final Thread t = new Thread(r, threadName);
            t.setDaemon(true);
            return t;
        }
    }
}
