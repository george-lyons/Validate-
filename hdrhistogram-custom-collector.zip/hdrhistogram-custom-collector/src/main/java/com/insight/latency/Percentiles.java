package com.insight.latency;

import java.util.Locale;

/**
 * Immutable percentile configuration.
 */
public final class Percentiles {
    private final double[] values;
    private final String[] labels;

    public Percentiles(final double... values) {
        if (values == null || values.length == 0) {
            throw new IllegalArgumentException("At least one percentile is required");
        }

        this.values = values.clone();
        this.labels = new String[values.length];

        double previous = -1.0d;
        for (int i = 0; i < this.values.length; i++) {
            final double value = this.values[i];
            if (value <= 0.0d || value > 100.0d) {
                throw new IllegalArgumentException("Percentile must be in (0, 100]: " + value);
            }
            if (value <= previous) {
                throw new IllegalArgumentException("Percentiles must be strictly increasing");
            }
            previous = value;
            this.labels[i] = formatLabel(value);
        }
    }

    public int size() {
        return values.length;
    }

    public double value(final int index) {
        return values[index];
    }

    public String label(final int index) {
        return labels[index];
    }

    private static String formatLabel(final double value) {
        if (value == Math.rint(value)) {
            return Long.toString((long) value);
        }
        final String s = String.format(Locale.ROOT, "%.6f", value);
        return s.indexOf('.') < 0 ? s : s.replaceAll("0+$", "").replaceAll("\.$", "");
    }
}
