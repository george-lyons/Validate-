package com.insight.latency.example;

import com.insight.latency.LatencyPublisher;
import com.insight.latency.Percentiles;
import com.insight.latency.PrometheusLatencyMetrics;
import com.insight.latency.StrategyLatency;
import io.prometheus.metrics.exporter.httpserver.HTTPServer;
import io.prometheus.metrics.model.registry.PrometheusRegistry;

import java.io.IOException;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;

/**
 * Tiny runnable example exposing /metrics on port 9400.
 */
public final class ExampleMain {
    public static void main(final String[] args) throws IOException {
        final String[] strategyNames = {"maker", "hedger", "router"};
        final StrategyLatency[] latencies = new StrategyLatency[strategyNames.length];
        for (int i = 0; i < latencies.length; i++) {
            latencies[i] = new StrategyLatency(TimeUnit.MILLISECONDS.toNanos(10), 3);
        }

        final Percentiles percentiles = new Percentiles(50.0, 95.0, 99.0, 99.9);
        final LatencyPublisher publisher = new LatencyPublisher(
                latencies,
                percentiles,
                1,
                TimeUnit.SECONDS,
                "latency-publisher"
        );
        publisher.start();

        final PrometheusRegistry registry = new PrometheusRegistry();
        new PrometheusLatencyMetrics(
                registry,
                "algo_strategy_latency",
                "strategy",
                strategyNames,
                percentiles,
                publisher
        );

        final HTTPServer server = HTTPServer.builder()
                .port(9400)
                .registry(registry)
                .buildAndStart();

        final WorkCycle.Strategy[] strategies = new WorkCycle.Strategy[] {
                () -> busyWaitNanos(10_000 + ThreadLocalRandom.current().nextLong(5_000)),
                () -> busyWaitNanos(25_000 + ThreadLocalRandom.current().nextLong(10_000)),
                () -> busyWaitNanos(40_000 + ThreadLocalRandom.current().nextLong(15_000))
        };

        final WorkCycle workCycle = new WorkCycle(strategies, latencies, 1_000_000L);

        while (true) {
            workCycle.runOneCycle();
            sleepQuietly(1);
        }
    }

    private static void busyWaitNanos(final long nanos) {
        final long start = System.nanoTime();
        while ((System.nanoTime() - start) < nanos) {
            // deliberate spin
        }
    }

    private static void sleepQuietly(final long millis) {
        try {
            Thread.sleep(millis);
        } catch (final InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
