package com.insight.latency;

import org.HdrHistogram.Histogram;
import org.HdrHistogram.SingleWriterRecorder;

/**
 * One recorder per strategy / owning thread.
 * Hot path is record(...); publisher thread periodically snapshots interval data.
 */
public final class StrategyLatency {
    private final SingleWriterRecorder recorder;
    private Histogram recycledIntervalHistogram;

    public StrategyLatency(final long highestTrackableValue, final int significantDigits) {
        this.recorder = new SingleWriterRecorder(highestTrackableValue, significantDigits);
    }

    public void record(final long latencyNanos) {
        if (latencyNanos >= 0L) {
            recorder.recordValue(latencyNanos);
        }
    }

    public void recordWithExpectedInterval(final long latencyNanos, final long expectedIntervalNanos) {
        if (latencyNanos < 0L) {
            return;
        }

        if (expectedIntervalNanos <= 0L) {
            recorder.recordValue(latencyNanos);
        } else {
            recorder.recordValueWithExpectedInterval(latencyNanos, expectedIntervalNanos);
        }
    }

    public Histogram snapshotInterval() {
        recycledIntervalHistogram = recorder.getIntervalHistogram(recycledIntervalHistogram);
        return recycledIntervalHistogram;
    }
}
