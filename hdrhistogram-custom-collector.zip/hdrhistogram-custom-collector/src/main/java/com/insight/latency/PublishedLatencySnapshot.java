package com.insight.latency;

/**
 * Scrape-visible snapshot buffer.
 * Written by the publisher thread, read by Prometheus scrape callbacks.
 */
final class PublishedLatencySnapshot {
    final long[][] percentileValues;
    final long[] maxValues;
    final long[] meanValues;
    final long[] counts;

    PublishedLatencySnapshot(final int strategyCount, final int percentileCount) {
        this.percentileValues = new long[strategyCount][percentileCount];
        this.maxValues = new long[strategyCount];
        this.meanValues = new long[strategyCount];
        this.counts = new long[strategyCount];
    }

    void clearStrategy(final int strategyIndex) {
        final long[] percentiles = percentileValues[strategyIndex];
        for (int i = 0; i < percentiles.length; i++) {
            percentiles[i] = 0L;
        }
        maxValues[strategyIndex] = 0L;
        meanValues[strategyIndex] = 0L;
        counts[strategyIndex] = 0L;
    }
}
