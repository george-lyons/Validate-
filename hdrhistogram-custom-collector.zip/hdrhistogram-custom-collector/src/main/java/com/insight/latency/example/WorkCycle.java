package com.insight.latency.example;

import com.insight.latency.StrategyLatency;

/**
 * Example strategy loop.
 */
public final class WorkCycle {
    private final Strategy[] strategies;
    private final StrategyLatency[] strategyLatencies;
    private final long expectedCycleIntervalNanos;

    public WorkCycle(
            final Strategy[] strategies,
            final StrategyLatency[] strategyLatencies,
            final long expectedCycleIntervalNanos) {
        this.strategies = strategies;
        this.strategyLatencies = strategyLatencies;
        this.expectedCycleIntervalNanos = expectedCycleIntervalNanos;
    }

    public void runOneCycle() {
        for (int i = 0; i < strategies.length; i++) {
            final long start = System.nanoTime();
            strategies[i].onCycle();
            final long elapsed = System.nanoTime() - start;
            strategyLatencies[i].recordWithExpectedInterval(elapsed, expectedCycleIntervalNanos);
        }
    }

    public interface Strategy {
        void onCycle();
    }
}
