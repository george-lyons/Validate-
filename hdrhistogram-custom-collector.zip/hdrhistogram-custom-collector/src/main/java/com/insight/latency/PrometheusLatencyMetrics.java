package com.insight.latency;

import io.prometheus.metrics.core.metrics.Gauge;
import io.prometheus.metrics.model.registry.PrometheusRegistry;

import java.util.Objects;

/**
 * Registers scrape callbacks against the latest published snapshot.
 * No histogram walking happens on scrape.
 */
public final class PrometheusLatencyMetrics {
    private final PrometheusRegistry registry;

    public PrometheusLatencyMetrics(
            final PrometheusRegistry registry,
            final String metricNamePrefix,
            final String strategyLabelName,
            final String[] strategyNames,
            final Percentiles percentiles,
            final LatencyPublisher publisher) {

        this.registry = Objects.requireNonNull(registry, "registry");
        Objects.requireNonNull(metricNamePrefix, "metricNamePrefix");
        Objects.requireNonNull(strategyLabelName, "strategyLabelName");
        Objects.requireNonNull(strategyNames, "strategyNames");
        Objects.requireNonNull(percentiles, "percentiles");
        Objects.requireNonNull(publisher, "publisher");

        for (int strategyIndex = 0; strategyIndex < strategyNames.length; strategyIndex++) {
            final int capturedStrategyIndex = strategyIndex;
            final String strategyName = strategyNames[strategyIndex];

            for (int percentileIndex = 0; percentileIndex < percentiles.size(); percentileIndex++) {
                final int capturedPercentileIndex = percentileIndex;
                Gauge.builder()
                        .name(metricNamePrefix + "_ns")
                        .help("Published strategy latency percentile in nanoseconds")
                        .labelNames(strategyLabelName, "percentile")
                        .register(registry)
                        .labelValues(strategyName, percentiles.label(percentileIndex))
                        .setCallback(callback -> callback.call(
                                (double) publisher.percentileValue(capturedStrategyIndex, capturedPercentileIndex)
                        ));
            }

            Gauge.builder()
                    .name(metricNamePrefix + "_ns_max")
                    .help("Published strategy latency max in nanoseconds")
                    .labelNames(strategyLabelName)
                    .register(registry)
                    .labelValues(strategyName)
                    .setCallback(callback -> callback.call((double) publisher.maxValue(capturedStrategyIndex)));

            Gauge.builder()
                    .name(metricNamePrefix + "_ns_mean")
                    .help("Published strategy latency mean in nanoseconds")
                    .labelNames(strategyLabelName)
                    .register(registry)
                    .labelValues(strategyName)
                    .setCallback(callback -> callback.call((double) publisher.meanValue(capturedStrategyIndex)));

            Gauge.builder()
                    .name(metricNamePrefix + "_interval_count")
                    .help("Number of latency observations in the last published interval")
                    .labelNames(strategyLabelName)
                    .register(registry)
                    .labelValues(strategyName)
                    .setCallback(callback -> callback.call((double) publisher.countValue(capturedStrategyIndex)));
        }
    }

    public PrometheusRegistry registry() {
        return registry;
    }
}
