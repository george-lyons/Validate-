# LatencyMetricSet

A simplified version of the histogram handoff design.

## Core idea

- hot path records into one `HdrHistogram Recorder` per metric label
- one background publisher calls `publish()` periodically
- `publish()` swaps interval histograms and writes a complete snapshot into an inactive buffer
- a single volatile flip makes the new snapshot visible to Micrometer scrape lambdas

## Main classes

- `Percentiles` - immutable configured percentile list
- `LatencyMetricSet` - owns recorders, snapshots and Micrometer registration
- `MetricsPublisher` - small scheduled publisher thread
- `WorkCycle` - example sequential strategy loop
- `InsightInfrastructure` - tiny wiring helper

## Usage

```java
PrometheusMeterRegistry registry = new PrometheusMeterRegistry(PrometheusConfig.DEFAULT);

LatencyMetricSet metricSet = new LatencyMetricSet(
    registry,
    "algo.latency",
    new String[]{"EUR_USD_HEDGE", "USD_JPY_HEDGE", "EUR_JPY_HEDGE"},
    Percentiles.DEFAULT
);

MetricsPublisher publisher = new MetricsPublisher(metricSet, 1, TimeUnit.SECONDS);
publisher.start();

metricSet.record(0, 82_000);
metricSet.recordWithExpectedInterval(1, 110_000, 500_000);
```

## Why this is simpler

The design is reduced to three actions:

- record
- publish
- scrape

There is no separate histogram wrapper, no separate gauge holder, no pool, and no direct raw array mutation from outside the metric set.
