package com.insight.benchmark;

import com.insight.metrics.LatencyMetricSet;
import com.insight.metrics.Percentiles;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;
import org.openjdk.jmh.annotations.Benchmark;
import org.openjdk.jmh.annotations.Scope;
import org.openjdk.jmh.annotations.Setup;
import org.openjdk.jmh.annotations.State;

@State(Scope.Thread)
public class LatencyRecordBenchmark {

    private LatencyMetricSet metricSet;

    @Setup
    public void setup() {
        metricSet = new LatencyMetricSet(
            new SimpleMeterRegistry(),
            "algo.latency",
            new String[]{"strategy-0", "strategy-1", "strategy-2"},
            Percentiles.DEFAULT
        );
    }

    @Benchmark
    public void record() {
        metricSet.record(0, 1_000);
    }

    @Benchmark
    public void recordWithExpectedInterval() {
        metricSet.recordWithExpectedInterval(0, 1_000, 500_000);
    }
}
