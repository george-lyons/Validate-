package com.insight.metrics.workcycle;

import com.insight.metrics.LatencyMetricSet;

/**
 * Sequential strategy loop that records one latency metric per strategy.
 */
public final class WorkCycle implements Runnable {

    @FunctionalInterface
    public interface Strategy {
        void onCycle();
    }

    private final Strategy[] strategies;
    private final LatencyMetricSet metricSet;
    private final long expectedCycleNs;
    private volatile boolean running = true;

    public WorkCycle(Strategy[] strategies,
                     LatencyMetricSet metricSet,
                     long expectedCycleNs) {
        if (strategies.length != metricSet.size()) {
            throw new IllegalArgumentException("strategies and metricSet size must match");
        }
        this.strategies = strategies;
        this.metricSet = metricSet;
        this.expectedCycleNs = expectedCycleNs;
    }

    @Override
    public void run() {
        while (running) {
            runOneCycle();
        }
    }

    public void runOneCycle() {
        for (int i = 0; i < strategies.length; i++) {
            long start = System.nanoTime();
            strategies[i].onCycle();
            long elapsed = System.nanoTime() - start;
            metricSet.recordWithExpectedInterval(i, elapsed, expectedCycleNs);
        }
    }

    public void stop() {
        running = false;
    }
}
