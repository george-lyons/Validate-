package com.insight.metrics;

import java.util.Arrays;

/**
 * Immutable configured percentile list used by LatencyMetricSet.
 */
public final class Percentiles {

    public static final Percentiles DEFAULT = Percentiles.of(50.0, 90.0, 99.0, 99.9, 99.99);
    public static final Percentiles TAIL_ONLY = Percentiles.of(99.0, 99.9, 99.99);
    public static final Percentiles MINIMAL = Percentiles.of(50.0, 99.0);

    private final double[] values;
    private final String[] labels;

    private Percentiles(double[] values, String[] labels) {
        this.values = values;
        this.labels = labels;
    }

    public static Percentiles of(double... values) {
        if (values == null || values.length == 0) {
            throw new IllegalArgumentException("At least one percentile is required");
        }
        double[] copy = Arrays.copyOf(values, values.length);
        String[] labels = new String[copy.length];
        double previous = -1.0;
        for (int i = 0; i < copy.length; i++) {
            double value = copy[i];
            if (value <= 0.0 || value > 100.0) {
                throw new IllegalArgumentException("Percentile must be in (0, 100], got " + value);
            }
            if (i > 0 && value <= previous) {
                throw new IllegalArgumentException("Percentiles must be strictly increasing");
            }
            previous = value;
            labels[i] = formatLabel(value);
        }
        return new Percentiles(copy, labels);
    }

    public int size() {
        return values.length;
    }

    public double value(int index) {
        return values[index];
    }

    public String label(int index) {
        return labels[index];
    }

    private static String formatLabel(double value) {
        String text = Double.toString(value);
        if (text.endsWith(".0")) {
            text = text.substring(0, text.length() - 2);
        }
        return "p" + text;
    }
}
