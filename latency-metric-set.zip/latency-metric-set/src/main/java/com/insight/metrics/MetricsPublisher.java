package com.insight.metrics;

import java.util.Objects;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * Small background publisher for one LatencyMetricSet.
 */
public final class MetricsPublisher {

    private final LatencyMetricSet metricSet;
    private final long interval;
    private final TimeUnit unit;
    private final ScheduledExecutorService scheduler;

    public MetricsPublisher(LatencyMetricSet metricSet, long interval, TimeUnit unit) {
        this.metricSet = Objects.requireNonNull(metricSet, "metricSet");
        this.interval = interval;
        this.unit = Objects.requireNonNull(unit, "unit");
        this.scheduler = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread thread = new Thread(r, "latency-metrics-publisher");
            thread.setDaemon(true);
            return thread;
        });
    }

    public void start() {
        scheduler.scheduleAtFixedRate(this::safePublish, interval, interval, unit);
    }

    public void publishNow() {
        safePublish();
    }

    public void stop() {
        scheduler.shutdown();
        try {
            scheduler.awaitTermination(5, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    private void safePublish() {
        try {
            metricSet.publish();
        } catch (Throwable t) {
            // Keep publisher alive; swap in your logger here.
            t.printStackTrace(System.err);
        }
    }
}
