package com.insight.metrics;

import com.insight.metrics.workcycle.WorkCycle;
import io.micrometer.core.instrument.MeterRegistry;

import java.util.concurrent.TimeUnit;

/**
 * Minimal wiring helper around LatencyMetricSet.
 */
public final class InsightInfrastructure {

    public static WiredWorkCycle build(String[] strategyNames,
                                       WorkCycle.Strategy[] strategies,
                                       long expectedCycleNs,
                                       Percentiles percentiles,
                                       MeterRegistry registry) {
        if (strategyNames.length != strategies.length) {
            throw new IllegalArgumentException("strategyNames and strategies must be the same length");
        }

        LatencyMetricSet metricSet = new LatencyMetricSet(
            registry,
            "algo.latency",
            strategyNames,
            percentiles
        );

        MetricsPublisher publisher = new MetricsPublisher(metricSet, 1, TimeUnit.SECONDS);
        WorkCycle workCycle = new WorkCycle(strategies, metricSet, expectedCycleNs);
        return new WiredWorkCycle(workCycle, metricSet, publisher);
    }

    public static final class WiredWorkCycle {
        private final WorkCycle workCycle;
        private final LatencyMetricSet metricSet;
        private final MetricsPublisher publisher;

        private WiredWorkCycle(WorkCycle workCycle,
                               LatencyMetricSet metricSet,
                               MetricsPublisher publisher) {
            this.workCycle = workCycle;
            this.metricSet = metricSet;
            this.publisher = publisher;
        }

        public WorkCycle workCycle() {
            return workCycle;
        }

        public LatencyMetricSet metricSet() {
            return metricSet;
        }

        public MetricsPublisher publisher() {
            return publisher;
        }
    }

    private InsightInfrastructure() {
    }
}
