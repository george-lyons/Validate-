package com.insight.metrics;

import io.micrometer.core.instrument.Gauge;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Tags;
import org.HdrHistogram.Histogram;
import org.HdrHistogram.Recorder;

/**
 * One coherent latency metric family.
 *
 * Example:
 * - one recorder per strategy or logical path
 * - one background publisher calls publish()
 * - Micrometer scrapes the currently published snapshot
 *
 * Hot path:
 * - record(metricIndex, valueNs)
 * - recordWithExpectedInterval(metricIndex, valueNs, expectedIntervalNs)
 *
 * Background path:
 * - publish()
 */
public final class LatencyMetricSet {

    private final Recorder[] recorders;
    private final Histogram[] intervalHistograms;
    private final String[] labels;
    private final Percentiles percentiles;
    private final Snapshot[] snapshots;
    private final String metricName;
    private volatile int activeSnapshotIndex;

    public LatencyMetricSet(MeterRegistry registry,
                            String metricName,
                            String[] metricLabels,
                            Percentiles percentiles,
                            long highestTrackableValue,
                            int significantDigits) {
        if (metricLabels == null || metricLabels.length == 0) {
            throw new IllegalArgumentException("At least one metric label is required");
        }
        this.metricName = metricName;
        this.labels = metricLabels.clone();
        this.percentiles = percentiles;
        this.recorders = new Recorder[labels.length];
        this.intervalHistograms = new Histogram[labels.length];
        for (int i = 0; i < labels.length; i++) {
            this.recorders[i] = new Recorder(highestTrackableValue, significantDigits);
            this.intervalHistograms[i] = new Histogram(highestTrackableValue, significantDigits);
        }
        this.snapshots = new Snapshot[] {
            new Snapshot(labels.length, percentiles.size()),
            new Snapshot(labels.length, percentiles.size())
        };
        registerGauges(registry);
    }

    public LatencyMetricSet(MeterRegistry registry,
                            String metricName,
                            String[] metricLabels,
                            Percentiles percentiles) {
        this(registry, metricName, metricLabels, percentiles, 10_000_000_000L, 3);
    }

    public void record(int metricIndex, long valueNs) {
        recorders[metricIndex].recordValue(valueNs);
    }

    public void recordWithExpectedInterval(int metricIndex, long valueNs, long expectedIntervalNs) {
        recorders[metricIndex].recordValueWithExpectedInterval(valueNs, expectedIntervalNs);
    }

    /**
     * Called from a single background publisher thread.
     * Publishes a fully written snapshot with one volatile flip at the end.
     */
    public void publish() {
        final int nextIndex = 1 - activeSnapshotIndex;
        final Snapshot target = snapshots[nextIndex];

        for (int i = 0; i < recorders.length; i++) {
            final Histogram interval = intervalHistograms[i];
            recorders[i].getIntervalHistogram(interval);

            for (int j = 0; j < percentiles.size(); j++) {
                target.percentileValues[i][j] = interval.getValueAtPercentile(percentiles.value(j));
            }

            target.max[i] = interval.getMaxValue();
            target.mean[i] = (long) interval.getMean();
            target.count[i] = interval.getTotalCount();
        }

        activeSnapshotIndex = nextIndex;
    }

    public int size() {
        return labels.length;
    }

    public String label(int index) {
        return labels[index];
    }

    public Percentiles percentiles() {
        return percentiles;
    }

    public long publishedPercentile(int metricIndex, int percentileIndex) {
        return snapshots[activeSnapshotIndex].percentileValues[metricIndex][percentileIndex];
    }

    public long publishedMax(int metricIndex) {
        return snapshots[activeSnapshotIndex].max[metricIndex];
    }

    public long publishedMean(int metricIndex) {
        return snapshots[activeSnapshotIndex].mean[metricIndex];
    }

    public long publishedCount(int metricIndex) {
        return snapshots[activeSnapshotIndex].count[metricIndex];
    }

    private void registerGauges(MeterRegistry registry) {
        for (int i = 0; i < labels.length; i++) {
            final int metricIndex = i;
            final Tags metricTags = Tags.of("metric", labels[i]);

            for (int j = 0; j < percentiles.size(); j++) {
                final int percentileIndex = j;
                Gauge.builder(metricName + ".ns", this,
                        set -> (double) set.publishedPercentile(metricIndex, percentileIndex))
                    .tags(metricTags.and("percentile", percentiles.label(percentileIndex)))
                    .description("Published latency percentile in nanoseconds")
                    .register(registry);
            }

            Gauge.builder(metricName + ".max.ns", this,
                    set -> (double) set.publishedMax(metricIndex))
                .tags(metricTags)
                .description("Published max latency in nanoseconds")
                .register(registry);

            Gauge.builder(metricName + ".mean.ns", this,
                    set -> (double) set.publishedMean(metricIndex))
                .tags(metricTags)
                .description("Published mean latency in nanoseconds")
                .register(registry);

            Gauge.builder(metricName + ".interval.count", this,
                    set -> (double) set.publishedCount(metricIndex))
                .tags(metricTags)
                .description("Published observation count for the last interval")
                .register(registry);
        }
    }

    private static final class Snapshot {
        private final long[][] percentileValues;
        private final long[] max;
        private final long[] mean;
        private final long[] count;

        private Snapshot(int metricCount, int percentileCount) {
            this.percentileValues = new long[metricCount][percentileCount];
            this.max = new long[metricCount];
            this.mean = new long[metricCount];
            this.count = new long[metricCount];
        }
    }
}
