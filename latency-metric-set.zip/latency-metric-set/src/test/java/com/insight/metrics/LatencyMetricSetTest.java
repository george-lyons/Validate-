package com.insight.metrics;

import io.micrometer.prometheus.PrometheusMeterRegistry;
import io.micrometer.prometheus.PrometheusConfig;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class LatencyMetricSetTest {

    @Test
    void publishesPercentilesIntoScrapeVisibleSnapshot() {
        PrometheusMeterRegistry registry = new PrometheusMeterRegistry(PrometheusConfig.DEFAULT);
        LatencyMetricSet set = new LatencyMetricSet(
            registry,
            "algo.latency",
            new String[]{"EUR_USD", "USD_JPY"},
            Percentiles.of(50.0, 99.0)
        );

        set.record(0, 100);
        set.record(0, 200);
        set.record(1, 1_000);
        set.publish();

        assertThat(set.publishedPercentile(0, 0)).isPositive();
        assertThat(set.publishedPercentile(1, 1)).isPositive();
        assertThat(set.publishedCount(0)).isEqualTo(2);
        assertThat(set.publishedCount(1)).isEqualTo(1);

        String scrape = registry.scrape();
        assertThat(scrape).contains("algo_latency_ns");
        assertThat(scrape).contains("algo_latency_interval_count");
    }
}
