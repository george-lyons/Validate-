package com.insight.metrics.example;

import com.insight.metrics.LatencyMetricSet;
import com.insight.metrics.MetricsPublisher;
import com.insight.metrics.Percentiles;
import io.micrometer.core.instrument.MeterRegistry;

import java.util.concurrent.TimeUnit;

/**
 * Example wiring.
 */
public final class InsightInfrastructure {
    private final LatencyMetricSet strategyLatency;
    private final MetricsPublisher publisher;

    public InsightInfrastructure(final MeterRegistry registry, final String[] strategyNames) {
        final Percentiles percentiles = new Percentiles(50.0, 95.0, 99.0, 99.9, 99.99);

        this.strategyLatency = new LatencyMetricSet(
                registry,
                "algo.strategy.latency.ns",
                "strategy",
                strategyNames,
                percentiles,
                TimeUnit.SECONDS.toNanos(10),
                3);

        this.publisher = new MetricsPublisher(
                strategyLatency,
                1,
                TimeUnit.SECONDS,
                "insight-metrics-publisher");
    }

    public LatencyMetricSet strategyLatency() {
        return strategyLatency;
    }

    public MetricsPublisher publisher() {
        return publisher;
    }
}
