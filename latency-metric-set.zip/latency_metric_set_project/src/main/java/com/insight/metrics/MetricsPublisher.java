package com.insight.metrics;

import java.util.Objects;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;

/**
 * Periodically publishes the latest interval histograms into a scrape-visible snapshot.
 */
public final class MetricsPublisher implements AutoCloseable {
    private final LatencyMetricSet metricSet;
    private final ScheduledExecutorService scheduler;
    private final long interval;
    private final TimeUnit intervalUnit;

    public MetricsPublisher(
            final LatencyMetricSet metricSet,
            final long interval,
            final TimeUnit intervalUnit,
            final String threadName) {

        this.metricSet = Objects.requireNonNull(metricSet, "metricSet");
        this.interval = interval;
        this.intervalUnit = Objects.requireNonNull(intervalUnit, "intervalUnit");
        this.scheduler = Executors.newSingleThreadScheduledExecutor(new NamedDaemonThreadFactory(threadName));
    }

    public void start() {
        scheduler.scheduleAtFixedRate(this::safePublish, interval, interval, intervalUnit);
    }

    public void publishNow() {
        safePublish();
    }

    @Override
    public void close() {
        scheduler.shutdownNow();
    }

    private void safePublish() {
        try {
            metricSet.publish();
        } catch (final Throwable t) {
            t.printStackTrace(System.err);
        }
    }

    private static final class NamedDaemonThreadFactory implements ThreadFactory {
        private final String threadName;

        private NamedDaemonThreadFactory(final String threadName) {
            this.threadName = threadName == null || threadName.isBlank() ? "metrics-publisher" : threadName;
        }

        @Override
        public Thread newThread(final Runnable r) {
            final Thread thread = new Thread(r, threadName);
            thread.setDaemon(true);
            return thread;
        }
    }
}
