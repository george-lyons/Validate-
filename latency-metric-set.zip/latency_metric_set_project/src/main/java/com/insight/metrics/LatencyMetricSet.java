package com.insight.metrics;

import io.micrometer.core.instrument.Gauge;
import io.micrometer.core.instrument.MeterRegistry;
import org.HdrHistogram.Histogram;
import org.HdrHistogram.Recorder;

/**
 * Owns a histogram recorder per metric label and exposes the latest published snapshot via Micrometer gauges.
 *
 * Usage:
 *  - hot path: record(index, nanos)
 *  - background publisher: publish()
 */
public final class LatencyMetricSet {
    private final String[] metricLabels;
    private final Recorder[] recorders;
    private final Percentiles percentiles;
    private final Snapshot[] snapshots;
    private volatile int activeSnapshotIndex;

    public LatencyMetricSet(
            final MeterRegistry registry,
            final String metricName,
            final String metricLabelKey,
            final String[] metricLabels,
            final Percentiles percentiles,
            final long highestTrackableValue,
            final int significantDigits) {

        if (registry == null) {
            throw new IllegalArgumentException("registry must not be null");
        }
        if (metricName == null || metricName.isBlank()) {
            throw new IllegalArgumentException("metricName must not be blank");
        }
        if (metricLabelKey == null || metricLabelKey.isBlank()) {
            throw new IllegalArgumentException("metricLabelKey must not be blank");
        }
        if (metricLabels == null || metricLabels.length == 0) {
            throw new IllegalArgumentException("metricLabels must not be empty");
        }
        if (percentiles == null) {
            throw new IllegalArgumentException("percentiles must not be null");
        }

        this.metricLabels = metricLabels.clone();
        this.recorders = new Recorder[metricLabels.length];
        this.percentiles = percentiles;
        this.snapshots = new Snapshot[] {
                new Snapshot(metricLabels.length, percentiles.size()),
                new Snapshot(metricLabels.length, percentiles.size())
        };
        this.activeSnapshotIndex = 0;

        for (int i = 0; i < recorders.length; i++) {
            recorders[i] = new Recorder(highestTrackableValue, significantDigits);
        }

        registerMeters(registry, metricName, metricLabelKey);
    }

    public void record(final int metricIndex, final long valueNs) {
        if (valueNs < 0L) {
            return;
        }
        recorders[metricIndex].recordValue(valueNs);
    }

    public void recordWithExpectedInterval(final int metricIndex, final long valueNs, final long expectedIntervalNs) {
        if (valueNs < 0L) {
            return;
        }
        if (expectedIntervalNs <= 0L) {
            record(metricIndex, valueNs);
            return;
        }
        recorders[metricIndex].recordValueWithExpectedInterval(valueNs, expectedIntervalNs);
    }

    /**
     * Called by a single background thread. Swaps interval histograms and atomically publishes a complete snapshot.
     */
    public void publish() {
        final int nextIndex = 1 - activeSnapshotIndex;
        final Snapshot target = snapshots[nextIndex];

        for (int i = 0; i < recorders.length; i++) {
            final Histogram interval = recorders[i].getIntervalHistogram();

            for (int j = 0; j < percentiles.size(); j++) {
                target.percentiles[i][j] = interval.getValueAtPercentile(percentiles.value(j));
            }

            target.max[i] = interval.getMaxValue();
            target.mean[i] = (long) interval.getMean();
            target.count[i] = interval.getTotalCount();
        }

        activeSnapshotIndex = nextIndex;
    }

    public int metricCount() {
        return metricLabels.length;
    }

    public String metricLabel(final int index) {
        return metricLabels[index];
    }

    public long percentileValue(final int metricIndex, final int percentileIndex) {
        return snapshots[activeSnapshotIndex].percentiles[metricIndex][percentileIndex];
    }

    public long maxValue(final int metricIndex) {
        return snapshots[activeSnapshotIndex].max[metricIndex];
    }

    public long meanValue(final int metricIndex) {
        return snapshots[activeSnapshotIndex].mean[metricIndex];
    }

    public long countValue(final int metricIndex) {
        return snapshots[activeSnapshotIndex].count[metricIndex];
    }

    private void registerMeters(final MeterRegistry registry, final String metricName, final String metricLabelKey) {
        for (int metricIndex = 0; metricIndex < metricLabels.length; metricIndex++) {
            final String metricLabel = metricLabels[metricIndex];
            final int capturedMetricIndex = metricIndex;

            for (int percentileIndex = 0; percentileIndex < percentiles.size(); percentileIndex++) {
                final int capturedPercentileIndex = percentileIndex;
                Gauge.builder(metricName, () -> (double) percentileValue(capturedMetricIndex, capturedPercentileIndex))
                        .baseUnit("nanoseconds")
                        .description("Published latency percentile in nanoseconds")
                        .tag(metricLabelKey, metricLabel)
                        .tag("percentile", percentiles.label(capturedPercentileIndex))
                        .register(registry);
            }

            Gauge.builder(metricName + ".max", () -> (double) maxValue(capturedMetricIndex))
                    .baseUnit("nanoseconds")
                    .description("Published latency max in nanoseconds")
                    .tag(metricLabelKey, metricLabel)
                    .register(registry);

            Gauge.builder(metricName + ".mean", () -> (double) meanValue(capturedMetricIndex))
                    .baseUnit("nanoseconds")
                    .description("Published latency mean in nanoseconds")
                    .tag(metricLabelKey, metricLabel)
                    .register(registry);

            Gauge.builder(metricName + ".interval.count", () -> (double) countValue(capturedMetricIndex))
                    .description("Observation count in the last published interval")
                    .tag(metricLabelKey, metricLabel)
                    .register(registry);
        }
    }

    private static final class Snapshot {
        private final long[][] percentiles;
        private final long[] max;
        private final long[] mean;
        private final long[] count;

        private Snapshot(final int metricCount, final int percentileCount) {
            this.percentiles = new long[metricCount][percentileCount];
            this.max = new long[metricCount];
            this.mean = new long[metricCount];
            this.count = new long[metricCount];
        }
    }
}
