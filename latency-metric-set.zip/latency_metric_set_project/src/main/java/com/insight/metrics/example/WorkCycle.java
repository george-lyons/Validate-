package com.insight.metrics.example;

import com.insight.metrics.LatencyMetricSet;

/**
 * Example work-cycle loop for N strategies.
 */
public final class WorkCycle {
    private final Strategy[] strategies;
    private final LatencyMetricSet strategyLatency;
    private final long expectedCycleNs;

    public WorkCycle(
            final Strategy[] strategies,
            final LatencyMetricSet strategyLatency,
            final long expectedCycleNs) {
        this.strategies = strategies;
        this.strategyLatency = strategyLatency;
        this.expectedCycleNs = expectedCycleNs;
    }

    public void runOneCycle() {
        for (int i = 0; i < strategies.length; i++) {
            final long start = System.nanoTime();
            strategies[i].onCycle();
            final long elapsed = System.nanoTime() - start;
            strategyLatency.recordWithExpectedInterval(i, elapsed, expectedCycleNs);
        }
    }

    public interface Strategy {
        void onCycle();
    }
}
