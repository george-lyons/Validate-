# latency-metric-set

Simplified histogram handoff design:

- `LatencyMetricSet` owns one `HdrHistogram Recorder` per metric label
- hot path calls `record(...)`
- one background thread calls `publish()`
- `publish()` swaps interval histograms and writes a complete double-buffered snapshot
- Micrometer gauges expose the latest published snapshot to Prometheus

## Main classes

- `Percentiles`
- `LatencyMetricSet`
- `MetricsPublisher`
- `example/WorkCycle`
- `example/InsightInfrastructure`

## Hot path

```java
strategyLatency.recordWithExpectedInterval(strategyIndex, elapsedNs, expectedCycleNs);
```

## Background thread

```java
publisher.start();
```

or

```java
publisher.publishNow();
```

## Notes

- The scrape-visible handoff is double-buffered.
- A single volatile flip publishes the latest completed snapshot.
- No custom histogram implementation.
- No ring buffer.
