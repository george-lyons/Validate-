package com.insight.metrics;

import com.insight.metrics.agent.InsightAgent;
import com.insight.metrics.gauge.InsightGauges;
import com.insight.metrics.histogram.AsyncHistogram;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;
import org.HdrHistogram.Histogram;
import org.junit.jupiter.api.Test;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import static org.assertj.core.api.Assertions.assertThat;

class AsyncHistogramTest {

    @Test
    void recordAndSwapReturnsAccumulatedValues() {
        AsyncHistogram h = new AsyncHistogram(0, "test", 500_000L);

        h.record(100_000L);
        h.record(200_000L);
        h.record(300_000L);

        Histogram interval = h.swap();

        assertThat(interval.getTotalCount()).isEqualTo(3);
        assertThat(interval.getValueAtPercentile(50.0)).isBetween(100_000L, 300_000L);
        assertThat(interval.getMaxValue()).isGreaterThanOrEqualTo(300_000L);
    }

    @Test
    void swapResetsAccumulator() {
        AsyncHistogram h = new AsyncHistogram(0, "test", 500_000L);

        h.record(100_000L);
        h.swap();   // first swap — clears interval

        // Record after swap
        h.record(999_000L);
        Histogram second = h.swap();

        // Only the post-swap observation should be present
        assertThat(second.getTotalCount()).isEqualTo(1);
        assertThat(second.getMaxValue()).isGreaterThanOrEqualTo(999_000L);
    }

    @Test
    void breachCountIncrementedWhenOverBudget() {
        long budgetNs = 100_000L;
        AsyncHistogram h = new AsyncHistogram(0, "test", budgetNs);

        h.record(50_000L);   // under budget — no breach
        h.record(150_000L);  // over budget — breach
        h.record(200_000L);  // over budget — breach

        assertThat(h.drainBreachCount()).isEqualTo(2);
    }

    @Test
    void drainBreachCountResetsCounter() {
        AsyncHistogram h = new AsyncHistogram(0, "test", 100_000L);
        h.record(200_000L);
        h.record(300_000L);

        assertThat(h.drainBreachCount()).isEqualTo(2);
        assertThat(h.drainBreachCount()).isEqualTo(0);  // reset after drain
    }

    @Test
    void swapFromDifferentThreadIsThreadSafe() throws InterruptedException {
        AsyncHistogram h = new AsyncHistogram(0, "test", 500_000L);
        CountDownLatch ready  = new CountDownLatch(1);
        CountDownLatch done   = new CountDownLatch(1);

        // Strategy thread — records 1000 values
        Thread strategyThread = new Thread(() -> {
            ready.countDown();
            for (int i = 0; i < 1000; i++) {
                h.record(100_000L + i);
            }
            done.countDown();
        });

        strategyThread.start();
        ready.await();

        // Agent thread — swaps mid-flight
        Histogram interval = h.swap();
        done.await(2, TimeUnit.SECONDS);

        // After strategy thread finishes, swap again to get remaining
        Histogram remainder = h.swap();

        // Total across both intervals must equal 1000
        long total = interval.getTotalCount() + remainder.getTotalCount();
        assertThat(total).isEqualTo(1000);
    }
}

class InsightAgentTest {

    @Test
    void agentWritesGaugesAfterInterval() throws InterruptedException {
        AsyncHistogram[] histograms = {
            new AsyncHistogram(0, "strategy-a", 500_000L),
            new AsyncHistogram(1, "strategy-b", 500_000L)
        };

        var registry = new SimpleMeterRegistry();
        InsightGauges gauges = new InsightGauges(histograms, registry);

        // Record some values before agent starts
        histograms[0].record(100_000L);
        histograms[0].record(200_000L);
        histograms[1].record(300_000L);

        // 100ms interval for test speed
        InsightAgent agent = new InsightAgent(histograms, gauges, null, 100_000_000L);
        agent.start();

        // Wait for at least one snapshot
        Thread.sleep(250);
        agent.stop();

        // Gauges should have been written
        assertThat(gauges.p99[0]).isGreaterThan(0L);
        assertThat(gauges.max[0]).isGreaterThanOrEqualTo(200_000L);
        assertThat(gauges.max[1]).isGreaterThanOrEqualTo(300_000L);
        assertThat(gauges.count[0]).isGreaterThan(0L);
    }

    @Test
    void agentClearsIntervalBetweenSnapshots() throws InterruptedException {
        AsyncHistogram[] histograms = {
            new AsyncHistogram(0, "strategy-a", 500_000L)
        };

        var registry = new SimpleMeterRegistry();
        InsightGauges gauges = new InsightGauges(histograms, registry);

        InsightAgent agent = new InsightAgent(histograms, gauges, null, 100_000_000L);
        agent.start();

        // Record in first interval
        histograms[0].record(999_000L);
        Thread.sleep(200);  // let first snapshot fire

        long maxAfterFirst = gauges.max[0];

        // Record nothing in second interval
        Thread.sleep(200);  // let second snapshot fire

        long countAfterSecond = gauges.count[0];
        agent.stop();

        assertThat(maxAfterFirst).isGreaterThanOrEqualTo(999_000L);
        // Count in second interval should be 0 (nothing recorded)
        assertThat(countAfterSecond).isEqualTo(0L);
    }
}
