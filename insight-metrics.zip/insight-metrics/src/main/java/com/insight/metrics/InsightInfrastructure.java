package com.insight.metrics;

import com.insight.metrics.agent.InsightAgent;
import com.insight.metrics.gauge.InsightGauges;
import com.insight.metrics.histogram.AsyncHistogram;
import com.insight.metrics.pool.HistogramPool;
import com.insight.metrics.ring.ThresholdHandler;
import com.insight.metrics.ring.ThresholdRingPublisher;
import com.insight.metrics.workcycle.WorkCycle;
import io.micrometer.core.instrument.MeterRegistry;

/**
 * InsightInfrastructure — assembles and wires all components.
 *
 * Call build() once at application startup. Returns a WorkCycle ready to
 * run on the strategy thread.
 *
 * Component lifecycle:
 *   InsightGauges       — registered with Micrometer at construction, lives forever
 *   HistogramPool       — pre-allocated at construction, ready for future ring path
 *   ThresholdPublisher  — optional; wired only if breachSink is non-null
 *   ThresholdHandler    — optional; daemon thread, started if breachSink is non-null
 *   InsightAgent        — started immediately; background daemon thread
 *   WorkCycle           — returned to caller; caller owns the strategy thread
 *
 * Future ring buffer upgrade path:
 *   When shared ring is introduced for full insights aggregation:
 *   1. InsightAgent.snapshotAll() acquires from histogramPool, copies interval
 *   2. Offers pool reference onto shared ring
 *   3. Insights consumer thread processes, releases back to pool
 *   WorkCycle, AsyncHistogram, and InsightGauges registration are unchanged.
 */
public final class InsightInfrastructure {

    /**
     * Build and start the complete metrics pipeline.
     *
     * @param strategyNames   names for Micrometer tags — one per strategy
     * @param targetCycleNs   target cycle time; used to compute per-strategy budgets
     * @param registry        Micrometer registry
     * @param breachSink      optional — receives breach events on handler thread;
     *                        null disables the ring buffer path entirely
     * @return WorkCycle ready to run on the strategy thread
     */
    public static WorkCycle build(String[]                      strategyNames,
                                  long                          targetCycleNs,
                                  MeterRegistry                 registry,
                                  ThresholdHandler.BreachSink   breachSink) {

        int n = strategyNames.length;

        // ── 1. AsyncHistograms — one per strategy ─────────────────────────────
        AsyncHistogram[] histograms = new AsyncHistogram[n];
        for (int i = 0; i < n; i++) {
            // Equal budget split: each strategy gets targetCycleNs / n
            // Adjust per-strategy if strategies have known unequal complexity
            long budgetNs = targetCycleNs / n;
            histograms[i] = new AsyncHistogram(i, strategyNames[i], budgetNs);
        }

        // ── 2. Gauges — registered once, Micrometer/Prometheus wired here ─────
        InsightGauges gauges = new InsightGauges(histograms, registry);

        // ── 3. HistogramPool — pre-allocated for future ring buffer path ───────
        // Not used today. Exists so the ring introduction requires no new alloc.
        // Capacity: 2 * n gives one in-flight per strategy plus headroom
        HistogramPool pool = new HistogramPool(
            2 * n, 10_000_000_000L, 3
        );

        // ── 4. Threshold ring path — optional ────────────────────────────────
        ThresholdRingPublisher publisher = null;
        if (breachSink != null) {
            publisher = new ThresholdRingPublisher();

            Thread handlerThread = new Thread(
                new ThresholdHandler(publisher.ring(), breachSink),
                "threshold-handler"
            );
            handlerThread.setDaemon(true);
            handlerThread.start();
        }

        // ── 5. Insight agent — starts background snapshot loop ────────────────
        InsightAgent agent = new InsightAgent(
            histograms,
            gauges,
            publisher,
            1_000_000_000L   // 1 second snapshot interval
        );
        agent.start();

        // ── 6. WorkCycle — returned; caller runs on strategy thread ───────────
        WorkCycle.Strategy[] strategies = new WorkCycle.Strategy[n];
        for (int i = 0; i < n; i++) {
            strategies[i] = () -> {};  // placeholder — caller replaces with real strategies
        }

        return new WorkCycle(strategies, histograms, targetCycleNs);
    }

    /**
     * Convenience overload — no threshold ring path.
     */
    public static WorkCycle build(String[]      strategyNames,
                                  long          targetCycleNs,
                                  MeterRegistry registry) {
        return build(strategyNames, targetCycleNs, registry, null);
    }

    private InsightInfrastructure() {}
}
