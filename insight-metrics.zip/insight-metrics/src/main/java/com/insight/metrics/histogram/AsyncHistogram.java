package com.insight.metrics.histogram;

import org.HdrHistogram.Histogram;
import org.HdrHistogram.Recorder;

import java.util.concurrent.atomic.AtomicLong;

/**
 * AsyncHistogram — producer-side histogram for the strategy thread.
 *
 * Threading contract:
 *   record()           — called ONLY on strategy (work cycle) thread
 *   swap()             — called ONLY on insight agent thread
 *   drainBreachCount() — called ONLY on insight agent thread
 *
 * The only cross-thread coordination is inside HdrHistogram's Recorder:
 * a single CAS on the internal buffer pointer when swap() is called.
 * The strategy thread participates only in record() — one volatile write, ~10ns.
 *
 * No lock. No allocation. No contention on the hot path.
 */
public final class AsyncHistogram {

    private final int        id;
    private final String     name;
    private final Recorder   recorder;
    private final Histogram  intervalHistogram;    // pre-allocated; agent owns after swap
    private final long       budgetNs;

    // Written by strategy thread on breach, drained by agent thread.
    // AtomicLong: ~10ns increment, acceptable on breach-only path.
    private final AtomicLong breachCount = new AtomicLong(0);

    /**
     * @param id        numeric ID — used as ring buffer key and gauge tag
     * @param name      human-readable label for Micrometer tags
     * @param budgetNs  per-cycle budget in nanoseconds; breach counted if exceeded
     */
    public AsyncHistogram(int id, String name, long budgetNs) {
        this.id               = id;
        this.name             = name;
        this.budgetNs         = budgetNs;
        // Track 1ns to 10s with 3 significant figures
        this.recorder         = new Recorder(10_000_000_000L, 3);
        this.intervalHistogram = new Histogram(10_000_000_000L, 3);
    }

    // =========================================================================
    // STRATEGY THREAD API
    // =========================================================================

    /**
     * Record a single observation.
     * Single volatile write into HdrHistogram dual buffer. ~10ns. No allocation.
     *
     * @param valueNs observation in nanoseconds
     */
    public void record(long valueNs) {
        recorder.recordValue(valueNs);
        if (valueNs > budgetNs) {
            breachCount.incrementAndGet();
        }
    }

    /**
     * Record with coordinated omission correction.
     *
     * Use this in preference to record() when strategies run sequentially.
     * If strategy[i-1] ran slow, strategy[i] started late. This fills in
     * the implied waiting time so p99/p999 reflect true end-to-end latency
     * rather than just processing time.
     *
     * @param valueNs            actual elapsed time in nanoseconds
     * @param expectedIntervalNs target cycle time — the interval strategy[i]
     *                           should have started at
     */
    public void record(long valueNs, long expectedIntervalNs) {
        recorder.recordValueWithExpectedInterval(valueNs, expectedIntervalNs);
        if (valueNs > budgetNs) {
            breachCount.incrementAndGet();
        }
    }

    // =========================================================================
    // INSIGHT AGENT THREAD API
    // =========================================================================

    /**
     * Atomically swap HdrHistogram's internal buffers.
     *
     * After this call:
     *   - returned Histogram contains ALL observations since the previous swap
     *   - strategy thread immediately writes to a fresh internal buffer
     *   - no observations are lost
     *
     * Cross-thread cost: one CAS + memory fence. ~20ns.
     * This is the ONLY point of coordination between strategy and agent threads.
     *
     * @return completed interval histogram — agent owns it until next swap()
     */
    public Histogram swap() {
        recorder.getIntervalHistogram(intervalHistogram);
        return intervalHistogram;
    }

    /**
     * Read and reset breach counter.
     * Called by agent thread only — safe because AtomicLong.getAndSet is atomic.
     */
    public long drainBreachCount() {
        return breachCount.getAndSet(0);
    }

    public int    id()       { return id; }
    public String name()     { return name; }
    public long   budgetNs() { return budgetNs; }
}
