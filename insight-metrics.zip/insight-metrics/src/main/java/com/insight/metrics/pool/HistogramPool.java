package com.insight.metrics.pool;

import org.HdrHistogram.Histogram;

import java.util.concurrent.ArrayBlockingQueue;

/**
 * HistogramPool — pre-allocated pool of Histogram instances.
 *
 * Purpose: when the shared ring buffer path is introduced, the insight agent
 * will acquire a slot from this pool, copy the swapped interval into it,
 * and offer the reference onto the ring. The insights consumer thread returns
 * the slot after processing.
 *
 * This class exists now — at zero cost — so that the ring buffer introduction
 * later requires no changes to AsyncHistogram or the agent's swap path.
 *
 * Today: not used (agent reads directly from swapped histogram).
 * Future: agent calls acquire(), copies into slot, offers slot ref onto ring.
 *
 * Threading:
 *   acquire() — called by insight agent thread
 *   release() — called by insights consumer thread (after ring introduction)
 */
public final class HistogramPool {

    private final ArrayBlockingQueue<Histogram> pool;
    private final int                           capacity;

    /**
     * @param capacity  number of pre-allocated Histogram slots.
     *                  Should be >= 2 * number of histograms to allow
     *                  one in-flight per histogram plus headroom.
     * @param maxValueNs  max trackable value — must match AsyncHistogram
     * @param sigFigures  significant figures — must match AsyncHistogram
     */
    public HistogramPool(int capacity, long maxValueNs, int sigFigures) {
        this.capacity = capacity;
        this.pool     = new ArrayBlockingQueue<>(capacity);
        for (int i = 0; i < capacity; i++) {
            pool.offer(new Histogram(maxValueNs, sigFigures));
        }
    }

    /**
     * Acquire a histogram slot from the pool.
     * Returns null if pool is exhausted — caller should drop the snapshot.
     * Non-blocking: never waits.
     */
    public Histogram acquire() {
        return pool.poll();
    }

    /**
     * Return a histogram slot to the pool after the consumer is done with it.
     * Resets the histogram before returning so it is clean for next use.
     */
    public void release(Histogram h) {
        h.reset();
        pool.offer(h);   // offer rather than put — never blocks
    }

    public int capacity()  { return capacity; }
    public int available() { return pool.size(); }
}
