package com.insight.metrics.agent;

import com.insight.metrics.gauge.InsightGauges;
import com.insight.metrics.histogram.AsyncHistogram;
import com.insight.metrics.ring.ThresholdRingPublisher;
import org.HdrHistogram.Histogram;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * InsightAgent — owns the snapshot interval and drives all histogram swaps.
 *
 * Responsibilities:
 *   1. On each interval: swap every AsyncHistogram (CAS buffer exchange)
 *   2. Read percentiles from the swapped interval histogram
 *   3. Write values directly to InsightGauges long[] arrays (Micrometer reads these)
 *   4. If max exceeds threshold: offer compact breach event onto SPSC ring
 *
 * Threading: single background thread ("insight-agent").
 *   - Coordinates with strategy thread ONLY via HdrHistogram CAS swap (~20ns)
 *   - Coordinates with Prometheus scrape ONLY via plain long[] array writes
 *   - Coordinates with handler thread ONLY via Agrona SPSC ring offer
 *   - Strategy thread never calls any method on this class
 *
 * Future ring buffer path:
 *   When shared ring is introduced, replace the direct gauge writes with
 *   pool.acquire() + copy + ring.offer(pooledHistogram).
 *   The swap() call and the threshold path remain identical.
 */
public final class InsightAgent {

    // Default: 3× budget = sustained blowout, not a transient spike
    private static final double THRESHOLD_MULTIPLIER = 3.0;

    private final AsyncHistogram[]       histograms;
    private final InsightGauges          gauges;
    private final ThresholdRingPublisher thresholdPublisher;   // null = no ring path
    private final long                   intervalNs;
    private final ScheduledExecutorService scheduler;

    /**
     * @param histograms          ordered array — indices match InsightGauges
     * @param gauges              pre-registered Micrometer gauge arrays
     * @param thresholdPublisher  ring publisher for KDB/external path; null to disable
     * @param intervalNs          snapshot interval in nanoseconds (e.g. 1_000_000_000L = 1s)
     */
    public InsightAgent(AsyncHistogram[]       histograms,
                        InsightGauges          gauges,
                        ThresholdRingPublisher thresholdPublisher,
                        long                   intervalNs) {
        this.histograms         = histograms;
        this.gauges             = gauges;
        this.thresholdPublisher = thresholdPublisher;
        this.intervalNs         = intervalNs;

        this.scheduler = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "insight-agent");
            t.setDaemon(true);
            t.setPriority(Thread.NORM_PRIORITY + 1);  // slight elevation over default
            return t;
        });
    }

    /** Start the snapshot interval. Call once at application startup. */
    public void start() {
        scheduler.scheduleAtFixedRate(
            this::snapshotAll,
            intervalNs,
            intervalNs,
            TimeUnit.NANOSECONDS
        );
    }

    /**
     * Snapshot all histograms.
     * Runs on insight-agent thread every intervalNs.
     */
    private void snapshotAll() {
        long now = System.nanoTime();

        for (int i = 0; i < histograms.length; i++) {
            AsyncHistogram h = histograms[i];

            // =================================================================
            // THE SWAP — only cross-thread coordination with strategy thread
            // CAS on HdrHistogram's internal buffer pointer. ~20ns.
            // After this line: interval contains ALL observations since last swap.
            // Strategy thread immediately begins writing to fresh buffer.
            // =================================================================
            Histogram interval = h.swap();

            // Read percentiles directly — no ring, no codec, no intermediate step
            long p50   = interval.getValueAtPercentile(50.0);
            long p99   = interval.getValueAtPercentile(99.0);
            long p999  = interval.getValueAtPercentile(99.9);
            long p9999 = interval.getValueAtPercentile(99.99);
            long max   = interval.getMaxValue();
            long count = interval.getTotalCount();

            // Write directly to gauge arrays — plain long[] writes, ~1ns each.
            // Prometheus scrape thread reads via Micrometer lambda on scrape cadence.
            // On a 64-bit JVM, long writes are atomic — no volatile or sync needed.
            gauges.p50[i]    = p50;
            gauges.p99[i]    = p99;
            gauges.p999[i]   = p999;
            gauges.p9999[i]  = p9999;
            gauges.max[i]    = max;
            gauges.mean[i]   = (long) interval.getMean();
            gauges.count[i]  = count;
            gauges.breach[i] = h.drainBreachCount();

            // =================================================================
            // EXCEPTIONAL PATH — ring buffer only when threshold exceeded
            // Normal Micrometer path above is NEVER affected by this branch.
            // =================================================================
            if (thresholdPublisher != null && max > h.budgetNs() * THRESHOLD_MULTIPLIER) {
                thresholdPublisher.offer(h.id(), now, interval);
            }
        }
    }

    /** Stop the agent. Does not affect strategy thread. */
    public void stop() {
        scheduler.shutdown();
        try {
            scheduler.awaitTermination(5, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
