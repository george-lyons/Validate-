package com.insight.metrics.ring;

import org.HdrHistogram.Histogram;
import org.agrona.concurrent.MessageHandler;
import org.agrona.concurrent.OneToOneRingBuffer;
import org.agrona.concurrent.UnsafeBuffer;

import java.nio.ByteBuffer;

/**
 * ThresholdRingPublisher — SPSC ring buffer writer for breach events.
 *
 * Used ONLY on the exceptional path: when a histogram's max exceeds a
 * configured threshold multiple, the insight agent writes a compact
 * ThresholdEvent onto this ring. A separate handler thread consumes
 * and writes to KDB or any slow/blocking external system.
 *
 * The normal Micrometer publish path does NOT use this ring.
 *
 * Threading:
 *   offer() — called by insight agent thread only (one producer)
 *   ring.read() — called by ThresholdHandler thread only (one consumer)
 *
 * On ring overflow: drop silently. Breach events are advisory.
 * The histogram gauges already captured the max value for Prometheus.
 */
public final class ThresholdRingPublisher {

    // 1024 slots × 36 bytes + Agrona header overhead
    // Breaches are rare — 1024 is ample headroom
    private static final int RING_CAPACITY = (1 << 10) * (ThresholdEvent.WIRE_SIZE + 8);
    private static final int MSG_TYPE      = 1;

    private final OneToOneRingBuffer ring;

    public ThresholdRingPublisher() {
        this.ring = new OneToOneRingBuffer(
            new UnsafeBuffer(ByteBuffer.allocateDirect(RING_CAPACITY))
        );
    }

    /**
     * Offer a breach event onto the ring.
     * Non-blocking. Drops silently on overflow.
     *
     * Called by insight agent thread only.
     */
    public void offer(int histogramId, long timestampNs, Histogram h) {
        int index = ring.tryClaim(MSG_TYPE, ThresholdEvent.WIRE_SIZE);
        if (index < 0) {
            // Ring full — drop. Handler thread is behind.
            // Ops alert should fire on handler lag, not here.
            return;
        }
        var buf = ring.buffer();
        buf.putInt( index + ThresholdEvent.OFFSET_ID,   histogramId);
        buf.putLong(index + ThresholdEvent.OFFSET_TS,   timestampNs);
        buf.putLong(index + ThresholdEvent.OFFSET_MAX,  h.getMaxValue());
        buf.putLong(index + ThresholdEvent.OFFSET_P999, h.getValueAtPercentile(99.9));
        buf.putLong(index + ThresholdEvent.OFFSET_CNT,  h.getTotalCount());
        ring.commit(index);
    }

    /**
     * Expose ring for handler thread consumption.
     * Handler calls ring.read() in its own loop.
     */
    public OneToOneRingBuffer ring() {
        return ring;
    }
}
