package com.insight.metrics.ring;

/**
 * ThresholdEvent — compact breach event written onto the SPSC ring.
 *
 * 36 bytes per event. Carries summary values only — no Histogram object.
 * The KDB/external handler needs these five fields; nothing more.
 *
 * Wire layout in Agrona ring buffer slot:
 *   [4B  histogramId ]
 *   [8B  timestampNs ]
 *   [8B  maxNs       ]
 *   [8B  p999Ns      ]
 *   [8B  count       ]
 *   = 36 bytes
 *
 * If a full Histogram snapshot is ever needed by the handler,
 * replace this with a HistogramPool slot reference (8 bytes — a pointer).
 * The pool is already wired in InsightInfrastructure for exactly that upgrade.
 */
public final class ThresholdEvent {

    public static final int WIRE_SIZE   = 36;
    public static final int OFFSET_ID   = 0;
    public static final int OFFSET_TS   = 4;
    public static final int OFFSET_MAX  = 12;
    public static final int OFFSET_P999 = 20;
    public static final int OFFSET_CNT  = 28;

    private ThresholdEvent() {}   // static utility — never instantiated
}
