package com.insight.metrics.workcycle;

import com.insight.metrics.histogram.AsyncHistogram;

/**
 * WorkCycle — strategy thread entry point.
 *
 * Loops N strategies sequentially. Records per-strategy latency into
 * AsyncHistogram using coordinated omission correction so that if
 * strategy[i-1] overruns, the implied wait time is captured in strategy[i]'s
 * histogram.
 *
 * The ONLY metrics interaction on this thread is:
 *   histograms[i].record(elapsed, expectedCycleNs)
 *   → single volatile write into HdrHistogram dual buffer
 *   → ~10ns, zero allocation
 *
 * Everything else (swap, percentile read, gauge write, ring offer) happens
 * on the insight agent thread and handler thread respectively.
 */
public final class WorkCycle implements Runnable {

    /**
     * Abstraction over a single strategy's processing unit.
     * Implementations should be allocation-free on the hot path.
     */
    @FunctionalInterface
    public interface Strategy {
        void onCycle();
    }

    private final Strategy[]        strategies;
    private final AsyncHistogram[]  histograms;      // parallel array — same index as strategies
    private final long              expectedCycleNs; // target cycle time for omission correction

    private volatile boolean running = true;

    /**
     * @param strategies       ordered strategy array — each runs once per cycle
     * @param histograms       parallel histogram array — histograms[i] records strategies[i]
     * @param expectedCycleNs  target cycle time in nanoseconds
     */
    public WorkCycle(Strategy[]       strategies,
                     AsyncHistogram[] histograms,
                     long             expectedCycleNs) {
        if (strategies.length != histograms.length) {
            throw new IllegalArgumentException(
                "strategies and histograms arrays must be same length");
        }
        this.strategies      = strategies;
        this.histograms      = histograms;
        this.expectedCycleNs = expectedCycleNs;
    }

    @Override
    public void run() {
        while (running && !Thread.currentThread().isInterrupted()) {
            runOneCycle();
        }
    }

    /**
     * Execute one complete work cycle.
     *
     * Uses a fixed-length array loop — no Iterator, no autoboxing, no allocation.
     * nanoTime() called twice per strategy: start and end.
     * Total instrumentation overhead per strategy: ~20ns (two nanoTime calls + record).
     */
    public void runOneCycle() {
        for (int i = 0; i < strategies.length; i++) {
            final long start = System.nanoTime();

            strategies[i].onCycle();

            final long elapsed = System.nanoTime() - start;

            // Coordinated omission correction:
            // If strategies[i-1] overran and delayed strategies[i]'s start,
            // this fills in the implied wait at expectedCycleNs intervals.
            // Gives honest p99/p999 rather than just processing time.
            histograms[i].record(elapsed, expectedCycleNs);
        }
    }

    public void stop() {
        running = false;
    }
}
