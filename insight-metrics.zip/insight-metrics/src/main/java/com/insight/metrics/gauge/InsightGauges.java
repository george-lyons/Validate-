package com.insight.metrics.gauge;

import com.insight.metrics.histogram.AsyncHistogram;
import io.micrometer.core.instrument.Gauge;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Tags;

/**
 * InsightGauges — long[] arrays registered with Micrometer once at startup.
 *
 * Design rationale:
 *   - Arrays are written by the insight agent thread (plain array write, ~1ns)
 *   - Micrometer gauge lambdas read the arrays on Prometheus scrape
 *   - On a 64-bit JVM, long writes are atomic — no synchronisation needed
 *   - Zero dynamic registration, zero map lookups, zero string construction
 *     during the agent's snapshot interval
 *
 * Threading:
 *   p99[i] = value  — insight agent thread (writes)
 *   () -> p99[idx]  — Prometheus scrape thread (reads via lambda)
 *   No strategy thread involvement.
 *
 * All values in nanoseconds. PromQL conversion to ms: value / 1e6
 */
public final class InsightGauges {

    // Package-visible — written directly by InsightAgent
    // One slot per histogram, indexed in parallel with AsyncHistogram[]
    final long[] p50;
    final long[] p99;
    final long[] p999;
    final long[] p9999;
    final long[] max;
    final long[] mean;
    final long[] count;
    final long[] breach;

    /**
     * Registers all gauges with Micrometer at construction time.
     * Never called again — no per-interval registration overhead.
     *
     * @param histograms  ordered array — indices must be stable for lifetime of process
     * @param registry    Micrometer registry (typically PrometheusMeterRegistry)
     */
    public InsightGauges(AsyncHistogram[] histograms, MeterRegistry registry) {
        int n   = histograms.length;
        p50     = new long[n];
        p99     = new long[n];
        p999    = new long[n];
        p9999   = new long[n];
        max     = new long[n];
        mean    = new long[n];
        count   = new long[n];
        breach  = new long[n];

        for (int i = 0; i < n; i++) {
            final int  idx  = i;
            final Tags tags = Tags.of("strategy", histograms[i].name());

            // Lambda captures array reference + index at registration time.
            // Prometheus reads current value by calling the lambda on each scrape.
            // No allocation, no lookup, just an array read.
            Gauge.builder("algo.latency.p50.ns",    () -> (double) p50[idx])   .tags(tags).register(registry);
            Gauge.builder("algo.latency.p99.ns",    () -> (double) p99[idx])   .tags(tags).register(registry);
            Gauge.builder("algo.latency.p999.ns",   () -> (double) p999[idx])  .tags(tags).register(registry);
            Gauge.builder("algo.latency.p9999.ns",  () -> (double) p9999[idx]) .tags(tags).register(registry);
            Gauge.builder("algo.latency.max.ns",    () -> (double) max[idx])   .tags(tags).register(registry);
            Gauge.builder("algo.latency.mean.ns",   () -> (double) mean[idx])  .tags(tags).register(registry);
            Gauge.builder("algo.latency.count",     () -> (double) count[idx]) .tags(tags).register(registry);
            Gauge.builder("algo.latency.breaches",  () -> (double) breach[idx]).tags(tags).register(registry);
        }
    }
}
