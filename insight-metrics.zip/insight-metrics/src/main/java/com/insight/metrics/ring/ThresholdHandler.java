package com.insight.metrics.ring;

import org.agrona.concurrent.OneToOneRingBuffer;

import java.util.concurrent.locks.LockSupport;
import java.util.function.LongConsumer;

/**
 * ThresholdHandler — consumes breach events from the SPSC ring.
 *
 * Runs on its own dedicated thread. Can block, allocate, call external
 * systems — completely decoupled from the strategy thread and insight agent.
 *
 * The sink is a functional interface so any downstream can be wired in:
 *   - KDB writer
 *   - alerting system
 *   - journal marker writer
 *   - log appender
 *
 * Threading: single consumer thread. One producer (ThresholdRingPublisher).
 */
public final class ThresholdHandler implements Runnable {

    /**
     * Receives decoded breach events.
     * Called on handler thread — can block/allocate freely.
     */
    @FunctionalInterface
    public interface BreachSink {
        void onBreach(int histogramId, long timestampNs,
                      long maxNs, long p999Ns, long count);
    }

    private static final long PARK_NS = 100_000L;  // 100µs yield when ring empty

    private final OneToOneRingBuffer ring;
    private final BreachSink         sink;

    public ThresholdHandler(OneToOneRingBuffer ring, BreachSink sink) {
        this.ring = ring;
        this.sink = sink;
    }

    @Override
    public void run() {
        while (!Thread.currentThread().isInterrupted()) {
            int read = ring.read((msgType, buf, index, length) -> {
                int  histogramId  = buf.getInt( index + ThresholdEvent.OFFSET_ID);
                long timestampNs  = buf.getLong(index + ThresholdEvent.OFFSET_TS);
                long maxNs        = buf.getLong(index + ThresholdEvent.OFFSET_MAX);
                long p999Ns       = buf.getLong(index + ThresholdEvent.OFFSET_P999);
                long count        = buf.getLong(index + ThresholdEvent.OFFSET_CNT);

                // Fully decoded — call sink which can block/allocate freely
                sink.onBreach(histogramId, timestampNs, maxNs, p999Ns, count);
            });

            // Park when ring is empty to avoid burning CPU
            // Does not affect strategy thread or agent thread
            if (read == 0) {
                LockSupport.parkNanos(PARK_NS);
            }
        }
    }
}
