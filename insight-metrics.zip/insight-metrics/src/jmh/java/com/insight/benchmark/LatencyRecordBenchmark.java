package com.insight.benchmark;

import com.insight.metrics.histogram.AsyncHistogram;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Timer;
import io.micrometer.prometheusmetrics.PrometheusConfig;
import io.micrometer.prometheusmetrics.PrometheusMeterRegistry;
import org.HdrHistogram.Histogram;
import org.HdrHistogram.Recorder;
import org.openjdk.jmh.annotations.*;
import org.openjdk.jmh.infra.Blackhole;
import org.openjdk.jmh.runner.Runner;
import org.openjdk.jmh.runner.RunnerException;
import org.openjdk.jmh.runner.options.Options;
import org.openjdk.jmh.runner.options.OptionsBuilder;

import java.util.concurrent.TimeUnit;

/**
 * JMH Benchmark — HDR record() vs Micrometer Timer.record() on strategy thread.
 *
 * What this measures:
 *   The cost of the single metrics call made on the hot path per strategy per cycle.
 *   This is the number that determines whether metrics impose meaningful latency
 *   on the work cycle thread.
 *
 * How to run:
 *   mvn package -q
 *   java -jar target/benchmarks.jar LatencyRecordBenchmark -rf json -rff results.json
 *
 * Or run specific benchmarks:
 *   java -jar target/benchmarks.jar ".*hdr.*"        # HDR variants only
 *   java -jar target/benchmarks.jar ".*micrometer.*" # Micrometer variants only
 *
 * JMH settings:
 *   Mode: AverageTime in nanoseconds — what you care about on the hot path
 *   Forks: 3 — guards against JVM startup and JIT variance
 *   Warmup: 5 iterations × 3s — ensure JIT is fully warmed
 *   Measurement: 10 iterations × 3s — stable measurement window
 *
 * Interpreting results:
 *   Score     = average time per operation in nanoseconds
 *   Error     = 99.9% confidence interval — should be narrow
 *   Compare   = hdrRecord vs micrometerTimerWithPercentiles on the same machine
 *
 * Expected ballpark (modern x86, JDK 17):
 *   hdrRecord                        ~10–15ns
 *   hdrRecordWithOmissionCorrection   ~15–20ns
 *   micrometerTimerBasic              ~50–100ns
 *   micrometerTimerWithPercentiles    ~200–500ns  (allocates internally)
 */
@BenchmarkMode(Mode.AverageTime)
@OutputTimeUnit(TimeUnit.NANOSECONDS)
@State(Scope.Thread)
@Warmup(iterations = 5, time = 3, timeUnit = TimeUnit.SECONDS)
@Measurement(iterations = 10, time = 3, timeUnit = TimeUnit.SECONDS)
@Fork(value = 3, jvmArgs = {
    "-XX:+UseZGC",
    "-Xms512m", "-Xmx512m",
    "-XX:+AlwaysPreTouch",
    "-XX:+DisableExplicitGC"
})
public class LatencyRecordBenchmark {

    // =========================================================================
    // State — shared setup for all benchmarks
    // =========================================================================

    // Simulated elapsed value — realistic strategy cycle time ~100µs
    private static final long SAMPLE_VALUE_NS    = 100_000L;
    private static final long EXPECTED_CYCLE_NS  = 500_000L;  // 500µs target cycle
    private static final long BUDGET_NS          = 200_000L;  // 200µs per strategy

    // ── HDR variants ──────────────────────────────────────────────────────────

    private AsyncHistogram asyncHistogram;
    private Recorder       rawRecorder;
    private Histogram      rawHistogram;  // for baseline comparison

    // ── Micrometer variants ───────────────────────────────────────────────────

    private MeterRegistry registry;
    private Timer         basicTimer;
    private Timer         percentilesTimer;    // publishPercentiles enabled
    private Timer         histogramTimer;      // publishHistogram enabled

    @Setup(Level.Trial)
    public void setup() {
        // HDR
        asyncHistogram = new AsyncHistogram(0, "benchmark-strategy", BUDGET_NS);
        rawRecorder    = new Recorder(10_000_000_000L, 3);
        rawHistogram   = new Histogram(10_000_000_000L, 3);

        // Micrometer with Prometheus backend — matches production config
        registry = new PrometheusMeterRegistry(PrometheusConfig.DEFAULT);

        // Basic timer — no percentiles, no histogram
        basicTimer = Timer.builder("bench.timer.basic")
            .description("Basic timer no percentiles")
            .register(registry);

        // Timer with percentiles — what most teams configure
        percentilesTimer = Timer.builder("bench.timer.percentiles")
            .description("Timer with publishPercentiles")
            .publishPercentiles(0.5, 0.99, 0.999)
            .register(registry);

        // Timer with full histogram — maximum Micrometer capability
        histogramTimer = Timer.builder("bench.timer.histogram")
            .description("Timer with publishPercentileHistogram")
            .publishPercentileHistogram(true)
            .register(registry);
    }

    // =========================================================================
    // HDR Benchmarks
    // =========================================================================

    /**
     * Our design: AsyncHistogram.record() on strategy thread.
     * Single volatile write into HdrHistogram dual buffer.
     * No allocation. No percentile computation. No gauge update.
     * All of that happens on the insight agent thread.
     */
    @Benchmark
    public void hdrAsyncRecord() {
        asyncHistogram.record(SAMPLE_VALUE_NS);
    }

    /**
     * AsyncHistogram.record() with coordinated omission correction.
     * Fills in implied waiting time — slightly more work than plain record().
     * Still no allocation. Still ~10-20ns.
     */
    @Benchmark
    public void hdrAsyncRecordWithOmissionCorrection() {
        asyncHistogram.record(SAMPLE_VALUE_NS, EXPECTED_CYCLE_NS);
    }

    /**
     * Raw HdrHistogram Recorder.recordValue() — the underlying mechanism.
     * Baseline to verify AsyncHistogram adds no meaningful overhead.
     */
    @Benchmark
    public void hdrRawRecorderRecord() {
        rawRecorder.recordValue(SAMPLE_VALUE_NS);
    }

    /**
     * Raw Histogram.recordValue() — no dual buffer, single histogram.
     * Included to show the cost floor: HdrHistogram's bucket write itself.
     */
    @Benchmark
    public void hdrRawHistogramRecord(Blackhole bh) {
        rawHistogram.recordValue(SAMPLE_VALUE_NS);
    }

    // =========================================================================
    // Micrometer Benchmarks
    // =========================================================================

    /**
     * Micrometer basic Timer.record() — no percentiles configured.
    * Closest to a fair comparison but not what teams actually deploy.
     */
    @Benchmark
    public void micrometerTimerBasic() {
        basicTimer.record(SAMPLE_VALUE_NS, TimeUnit.NANOSECONDS);
    }

    /**
     * Micrometer Timer with publishPercentiles.
     * THIS IS WHAT MOST TEAMS DEPLOY when they want p99 in Prometheus.
     * Records observation AND updates percentile estimators internally.
     * May allocate depending on internal digest implementation.
     */
    @Benchmark
    public void micrometerTimerWithPercentiles() {
        percentilesTimer.record(SAMPLE_VALUE_NS, TimeUnit.NANOSECONDS);
    }

    /**
     * Micrometer Timer with publishPercentileHistogram.
     * Full histogram mode — maximum data richness but highest recording cost.
     * Records into HDR internally but via Micrometer's wrapper overhead.
     */
    @Benchmark
    public void micrometerTimerWithHistogram() {
        histogramTimer.record(SAMPLE_VALUE_NS, TimeUnit.NANOSECONDS);
    }

    /**
     * Micrometer Timer.record() with lambda — alternative API some teams use.
     * Included because the lambda closure may affect JIT behaviour.
     */
    @Benchmark
    public void micrometerTimerWithLambda(Blackhole bh) {
        long result = percentilesTimer.record(() -> {
            // Simulate strategy work via Blackhole to prevent dead-code elimination
            bh.consume(SAMPLE_VALUE_NS);
            return SAMPLE_VALUE_NS;
        });
        bh.consume(result);
    }

    // =========================================================================
    // Main — run directly from IDE or use: java -jar target/benchmarks.jar
    // =========================================================================

    public static void main(String[] args) throws RunnerException {
        Options opt = new OptionsBuilder()
            .include(LatencyRecordBenchmark.class.getSimpleName())
            .forks(1)           // reduce to 1 for quick local run
            .warmupIterations(3)
            .measurementIterations(5)
            .build();

        new Runner(opt).run();
    }
}
