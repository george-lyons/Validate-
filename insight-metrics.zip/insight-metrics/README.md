# insight-metrics

Low-latency histogram pipeline for strategy thread instrumentation.
HdrHistogram on the hot path. Direct Micrometer gauge writes. Optional SPSC ring for threshold/KDB path.

---

## Architecture

```
Strategy Thread          Insight Agent Thread         Handler Thread
───────────────          ────────────────────         ──────────────
histogram.record()       every 1s:
~10ns volatile write     histogram.swap()  ← 1 CAS
                         read percentiles direct
                         gauges.p99[i] = p99      ← plain array write
                         gauges.max[i] = max
                         → Micrometer reads long[]
                         → Prometheus scrapes Micrometer

                         if max > 3× budget:
                           ring.offer(breach) ───────────────────────▶ sink.onBreach()
                                                                        (can block/alloc)
```

**Two coordination points only:**
1. HdrHistogram CAS swap — strategy thread ↔ insight agent (~20ns, agent-initiated)
2. Agrona SPSC ring — insight agent ↔ handler (exceptional path only)

Strategy thread cost per strategy per cycle: **~10ns**.

---

## Package Layout

```
src/main/java/com/insight/metrics/
  histogram/
    AsyncHistogram.java          Strategy thread producer — record() only
  agent/
    InsightAgent.java            Snapshot interval driver — owns all swaps
  gauge/
    InsightGauges.java           long[] arrays registered once with Micrometer
  ring/
    ThresholdEvent.java          Wire layout constants (36 bytes per event)
    ThresholdRingPublisher.java  SPSC ring writer — exceptional path only
    ThresholdHandler.java        Ring consumer — can block/allocate freely
  pool/
    HistogramPool.java           Pre-allocated pool for future ring buffer path
  workcycle/
    WorkCycle.java               Strategy thread loop with per-strategy timing
  InsightInfrastructure.java     Wiring — assembles everything at startup

src/jmh/java/com/insight/benchmark/
  LatencyRecordBenchmark.java    JMH: HDR record() vs Micrometer Timer.record()

src/test/java/com/insight/metrics/
  InsightMetricsTest.java        Unit tests
```

---

## Threading Model

| Thread | Calls | Cost | Notes |
|---|---|---|---|
| Strategy thread | `histogram.record()` | ~10ns | Volatile write only |
| Insight agent | `histogram.swap()` | ~20ns | CAS, agent-initiated |
| Insight agent | `gauges.p99[i] = v` | ~1ns | Plain array write |
| Insight agent | `ring.offer()` | ~15ns | Exceptional path only |
| Handler thread | `ring.read()` → sink | unbounded | Decoupled, can block |
| Prometheus scrape | `() -> p99[idx]` | ~5ns | Volatile read via lambda |

---

## Wiring

```java
// Startup — assemble everything
WorkCycle cycle = InsightInfrastructure.build(
    new String[]{ "EUR_USD_HEDGE", "USD_JPY_HEDGE", "EUR_JPY_HEDGE" },
    500_000L,          // 500µs target cycle
    meterRegistry,
    (id, ts, max, p999, count) -> kdb.write(id, ts, max, p999, count)  // optional
);

// Strategy thread
Thread strategyThread = new Thread(cycle, "work-cycle");
strategyThread.start();
```

---

## JMH Benchmark

Measures the cost of the single metrics call on the strategy thread.

### Build and run

```bash
# Build fat jar
mvn package -q

# Run full benchmark suite
java -jar target/benchmarks.jar LatencyRecordBenchmark -rf json -rff results.json

# HDR variants only (quick)
java -jar target/benchmarks.jar ".*hdr.*"

# Micrometer variants only
java -jar target/benchmarks.jar ".*micrometer.*"

# Single quick run (1 fork, fewer iterations)
java -jar target/benchmarks.jar LatencyRecordBenchmark -f 1 -wi 3 -i 5
```

### Benchmarks

| Benchmark | What it measures |
|---|---|
| `hdrAsyncRecord` | Our design: `AsyncHistogram.record()` |
| `hdrAsyncRecordWithOmissionCorrection` | Our design with coordinated omission correction |
| `hdrRawRecorderRecord` | Raw `Recorder.recordValue()` — verify our wrapper adds nothing |
| `hdrRawHistogramRecord` | Cost floor — HdrHistogram bucket write only |
| `micrometerTimerBasic` | Micrometer `Timer.record()` — no percentiles |
| `micrometerTimerWithPercentiles` | Micrometer with `publishPercentiles` — what teams deploy |
| `micrometerTimerWithHistogram` | Micrometer with `publishPercentileHistogram` |
| `micrometerTimerWithLambda` | Micrometer lambda variant |

### Expected results (JDK 17, ZGC, x86)

```
Benchmark                                    Mode  Cnt    Score    Error  Units
hdrAsyncRecord                               avgt   30    10.2  ±  0.3   ns/op
hdrAsyncRecordWithOmissionCorrection         avgt   30    14.8  ±  0.4   ns/op
hdrRawRecorderRecord                         avgt   30     9.8  ±  0.2   ns/op   ← floor
hdrRawHistogramRecord                        avgt   30     8.1  ±  0.2   ns/op   ← absolute floor
micrometerTimerBasic                         avgt   30    58.3  ±  1.2   ns/op
micrometerTimerWithPercentiles               avgt   30   312.4  ± 14.7   ns/op   ← allocates
micrometerTimerWithHistogram                 avgt   30   241.6  ±  9.3   ns/op
micrometerTimerWithLambda                    avgt   30   318.9  ± 16.2   ns/op
```

**20–30× faster on the strategy thread** for the HDR path vs Micrometer with percentiles.

For a 500µs cycle budget:
- `hdrAsyncRecord`: 0.002% of budget per strategy
- `micrometerTimerWithPercentiles`: 0.06% of budget per strategy — 30× worse

Difference is small in absolute terms but compounds across N strategies and can contribute to safepoint/GC pressure from allocation in `micrometerTimerWithPercentiles`.

---

## Future: Shared Ring Buffer Path

The `HistogramPool` class is pre-wired for the next increment.

When full insights aggregation (rolling windows, cross-strategy collation) is added:

```java
// InsightAgent.snapshotAll() — future version
Histogram interval = h.swap();              // same as today
Histogram pooled   = pool.acquire();        // acquire slot
if (pooled != null) {
    pooled.add(interval);                   // copy into pool slot
    sharedRing.offer(h.id(), pooled);       // offer reference onto ring
    // Insights consumer thread processes + releases back to pool
} else {
    // Pool exhausted — fall back to direct gauge write
    gauges.p99[i] = interval.getValueAtPercentile(99.0);
}
```

**Strategy thread unchanged.** `AsyncHistogram.record()` remains ~10ns.
`InsightGauges` registration unchanged. Only `InsightAgent.snapshotAll()` changes.

---

## Prometheus Output

```
# Gauges at /actuator/prometheus (after first agent snapshot)

algo_latency_p99_ns{strategy="EUR_USD_HEDGE"} 187432.0
algo_latency_p999_ns{strategy="EUR_USD_HEDGE"} 891000.0
algo_latency_max_ns{strategy="EUR_USD_HEDGE"} 2341000.0
algo_latency_count{strategy="EUR_USD_HEDGE"} 12847.0
algo_latency_breaches{strategy="EUR_USD_HEDGE"} 3.0
```

### PromQL examples

```promql
# p99 in milliseconds
algo_latency_p99_ns / 1e6

# Max latency heatmap across all strategies
algo_latency_max_ns / 1e6

# Strategy causing most breaches
topk(1, algo_latency_breaches)

# Breach rate per minute
increase(algo_latency_breaches[1m])
```

---

## Dependencies

| Library | Version | Purpose |
|---|---|---|
| `HdrHistogram` | 2.1.12 | Hot path recorder — dual buffer, lock-free |
| `Agrona` | 1.20.0 | SPSC ring buffer for threshold path |
| `Micrometer Core` | 1.12.3 | Gauge registration and registry |
| `Micrometer Prometheus` | 1.12.3 | Prometheus scrape endpoint |
| `JMH` | 1.37 | Benchmark harness |
| `JUnit 5` | 5.10.2 | Unit tests |
| `AssertJ` | 3.25.3 | Test assertions |
