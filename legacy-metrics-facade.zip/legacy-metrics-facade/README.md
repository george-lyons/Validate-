# Legacy Metrics Facade

A small example of a legacy-friendly metrics facade around Micrometer + Prometheus.

## What it gives you

- one metrics bootstrap on JVM startup
- one configured HTTP scrape port
- JVM metrics bound once
- static global access from anywhere in the codebase
- your own interfaces around counter, timer, and summary
- custom tags supported
- Micrometer hidden behind your own facade so you can swap later

## Main classes

- `Metrics` - global static facade
- `MetricFactory` - abstraction
- `MetricCounter`, `MetricTimer`, `MetricSummary` - your own interfaces
- `MetricTags` - your own small tag wrapper
- `MicrometerMetricFactory` - implementation
- `MetricsBootstrap` - creates registry, binds JVM meters, starts HTTP server

## Startup

```java
MetricsBootstrap.initPrometheus(9464);
```

## Usage

```java
private static final MetricCounter HEDGES_SENT =
        Metrics.counter(
                "hedges_sent_total",
                "Total hedges sent",
                MetricTags.of("component", "hedger"));

private static final MetricTimer STRATEGY_CYCLE =
        Metrics.timer(
                "strategy_cycle_latency",
                "Latency of strategy cycle",
                MetricTags.of("component", "hedger"));

public void runCycle(String venue, boolean success) {
    HEDGES_SENT.increment();

    MetricTimer.Sample sample = STRATEGY_CYCLE.start();
    try {
        MetricTimer venueTimer = Metrics.timer(
                "order_send_latency",
                "Latency of order send",
                MetricTags.of("venue", venue, "status", success ? "success" : "fail"));

        venueTimer.record(250, java.util.concurrent.TimeUnit.MICROSECONDS);
    } finally {
        sample.stop();
    }
}
```

## Prometheus examples

Count in last minute from timer:

```promql
increase(strategy_cycle_latency_seconds_count[1m])
```

P99 in last minute:

```promql
histogram_quantile(0.99, rate(strategy_cycle_latency_seconds_bucket[1m]))
```

Per-minute throughput:

```promql
rate(strategy_cycle_latency_seconds_count[1m]) * 60
```

## Notes

- define hot-path metrics once as `static final` where possible
- avoid high-cardinality tags like request id, order id, error message
- use `MetricTimer` for latency and `MetricSummary` for numeric distributions such as order size
