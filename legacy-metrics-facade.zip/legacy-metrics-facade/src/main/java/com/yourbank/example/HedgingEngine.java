package com.yourbank.example;

import com.yourbank.metrics.MetricCounter;
import com.yourbank.metrics.MetricSummary;
import com.yourbank.metrics.MetricTags;
import com.yourbank.metrics.MetricTimer;
import com.yourbank.metrics.Metrics;

import java.util.concurrent.TimeUnit;

public final class HedgingEngine {
    private static final MetricCounter HEDGES_SENT =
            Metrics.counter(
                    "hedges_sent_total",
                    "Total hedges sent",
                    MetricTags.of("component", "hedger"));

    private static final MetricTimer STRATEGY_CYCLE =
            Metrics.timer(
                    "strategy_cycle_latency",
                    "Latency of strategy cycle",
                    MetricTags.of("component", "hedger"));

    private static final MetricSummary ORDER_SIZE =
            Metrics.summary(
                    "order_size",
                    "Order size distribution",
                    MetricTags.of("component", "hedger"));

    public void runCycle(final String venue, final boolean success) {
        HEDGES_SENT.increment();

        final MetricTimer.Sample sample = STRATEGY_CYCLE.start();
        try {
            final MetricTimer venueTimer = Metrics.timer(
                    "order_send_latency",
                    "Latency of order send",
                    MetricTags.of("venue", venue, "status", success ? "success" : "fail"));

            venueTimer.record(250, TimeUnit.MICROSECONDS);
            ORDER_SIZE.record(success ? 2_500_000 : 500_000);
        } finally {
            sample.stop();
        }
    }
}
