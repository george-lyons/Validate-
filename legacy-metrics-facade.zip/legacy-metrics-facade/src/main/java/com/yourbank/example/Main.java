package com.yourbank.example;

import com.yourbank.metrics.MetricsBootstrap;

public final class Main {
    private Main() {
    }

    public static void main(final String[] args) {
        MetricsBootstrap.initPrometheus(9464);

        final HedgingEngine hedgingEngine = new HedgingEngine();
        hedgingEngine.runCycle("EBS", true);
        hedgingEngine.runCycle("REUTERS", false);

        System.out.println("Metrics on http://localhost:9464/metrics");
    }
}
