package com.yourbank.metrics;

import java.util.Objects;

public final class Metrics {
    private static volatile MetricFactory FACTORY = new NoOpMetricFactory();

    private Metrics() {
    }

    public static void init(final MetricFactory factory) {
        FACTORY = Objects.requireNonNull(factory, "factory");
    }

    public static MetricCounter counter(final String name, final String description) {
        return FACTORY.counter(name, description);
    }

    public static MetricCounter counter(final String name, final String description, final MetricTags tags) {
        return FACTORY.counter(name, description, tags);
    }

    public static MetricTimer timer(final String name, final String description) {
        return FACTORY.timer(name, description);
    }

    public static MetricTimer timer(final String name, final String description, final MetricTags tags) {
        return FACTORY.timer(name, description, tags);
    }

    public static MetricSummary summary(final String name, final String description) {
        return FACTORY.summary(name, description);
    }

    public static MetricSummary summary(final String name, final String description, final MetricTags tags) {
        return FACTORY.summary(name, description, tags);
    }
}
