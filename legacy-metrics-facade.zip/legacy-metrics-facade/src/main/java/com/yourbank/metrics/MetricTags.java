package com.yourbank.metrics;

import java.util.Arrays;
import java.util.Objects;

public final class MetricTags {
    private static final MetricTags EMPTY = new MetricTags(new String[0]);

    private final String[] keyValues;

    private MetricTags(final String[] keyValues) {
        this.keyValues = keyValues;
    }

    public static MetricTags empty() {
        return EMPTY;
    }

    public static MetricTags of(final String... keyValues) {
        Objects.requireNonNull(keyValues, "keyValues");
        if ((keyValues.length & 1) != 0) {
            throw new IllegalArgumentException("Tags must be key/value pairs");
        }
        return new MetricTags(Arrays.copyOf(keyValues, keyValues.length));
    }

    public MetricTags and(final String key, final String value) {
        final String[] merged = Arrays.copyOf(keyValues, keyValues.length + 2);
        merged[keyValues.length] = key;
        merged[keyValues.length + 1] = value;
        return new MetricTags(merged);
    }

    public String[] keyValues() {
        return Arrays.copyOf(keyValues, keyValues.length);
    }
}
