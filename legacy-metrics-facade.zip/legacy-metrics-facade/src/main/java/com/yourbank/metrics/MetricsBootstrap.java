package com.yourbank.metrics;

import com.yourbank.metrics.micrometer.MetricsHttpServer;
import com.yourbank.metrics.micrometer.MicrometerMetricFactory;
import io.micrometer.core.instrument.binder.jvm.ClassLoaderMetrics;
import io.micrometer.core.instrument.binder.jvm.JvmGcMetrics;
import io.micrometer.core.instrument.binder.jvm.JvmMemoryMetrics;
import io.micrometer.core.instrument.binder.jvm.JvmThreadMetrics;
import io.micrometer.core.instrument.binder.system.ProcessorMetrics;
import io.micrometer.prometheusmetrics.PrometheusConfig;
import io.micrometer.prometheusmetrics.PrometheusMeterRegistry;

public final class MetricsBootstrap {
    private MetricsBootstrap() {
    }

    public static PrometheusMeterRegistry initPrometheus(final int port) {
        final PrometheusMeterRegistry registry =
                new PrometheusMeterRegistry(PrometheusConfig.DEFAULT);

        new ClassLoaderMetrics().bindTo(registry);
        new JvmMemoryMetrics().bindTo(registry);
        new JvmGcMetrics().bindTo(registry);
        new ProcessorMetrics().bindTo(registry);
        new JvmThreadMetrics().bindTo(registry);

        Metrics.init(new MicrometerMetricFactory(registry));
        MetricsHttpServer.start(registry, port);
        return registry;
    }
}
