package com.yourbank.metrics;

public interface MetricCounter {
    void increment();
    void add(double amount);
}
