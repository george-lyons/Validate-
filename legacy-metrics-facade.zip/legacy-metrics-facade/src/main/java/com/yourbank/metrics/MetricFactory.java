package com.yourbank.metrics;

public interface MetricFactory {
    MetricCounter counter(String name, String description);
    MetricCounter counter(String name, String description, MetricTags tags);

    MetricTimer timer(String name, String description);
    MetricTimer timer(String name, String description, MetricTags tags);

    MetricSummary summary(String name, String description);
    MetricSummary summary(String name, String description, MetricTags tags);
}
