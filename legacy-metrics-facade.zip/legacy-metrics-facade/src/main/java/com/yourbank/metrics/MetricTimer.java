package com.yourbank.metrics;

import java.util.concurrent.TimeUnit;

public interface MetricTimer {
    void record(long amount, TimeUnit unit);
    Sample start();

    interface Sample {
        void stop();
    }
}
