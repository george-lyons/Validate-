package com.yourbank.metrics;

import java.util.concurrent.TimeUnit;

public final class NoOpMetricFactory implements MetricFactory {
    private static final MetricCounter COUNTER = new MetricCounter() {
        @Override
        public void increment() {
        }

        @Override
        public void add(final double amount) {
        }
    };

    private static final MetricTimer TIMER = new MetricTimer() {
        private static final Sample SAMPLE = () -> { };

        @Override
        public void record(final long amount, final TimeUnit unit) {
        }

        @Override
        public Sample start() {
            return SAMPLE;
        }
    };

    private static final MetricSummary SUMMARY = amount -> { };

    @Override
    public MetricCounter counter(final String name, final String description) {
        return COUNTER;
    }

    @Override
    public MetricCounter counter(final String name, final String description, final MetricTags tags) {
        return COUNTER;
    }

    @Override
    public MetricTimer timer(final String name, final String description) {
        return TIMER;
    }

    @Override
    public MetricTimer timer(final String name, final String description, final MetricTags tags) {
        return TIMER;
    }

    @Override
    public MetricSummary summary(final String name, final String description) {
        return SUMMARY;
    }

    @Override
    public MetricSummary summary(final String name, final String description, final MetricTags tags) {
        return SUMMARY;
    }
}
