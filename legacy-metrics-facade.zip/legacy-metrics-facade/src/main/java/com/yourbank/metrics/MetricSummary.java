package com.yourbank.metrics;

public interface MetricSummary {
    void record(double amount);
}
