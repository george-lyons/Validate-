package com.yourbank.metrics.micrometer;

import com.yourbank.metrics.MetricCounter;
import com.yourbank.metrics.MetricFactory;
import com.yourbank.metrics.MetricSummary;
import com.yourbank.metrics.MetricTags;
import com.yourbank.metrics.MetricTimer;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.DistributionSummary;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Timer;

import java.util.Arrays;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;

public final class MicrometerMetricFactory implements MetricFactory {
    private final MeterRegistry registry;
    private final ConcurrentHashMap<MeterKey, MetricCounter> counters = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<MeterKey, MetricTimer> timers = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<MeterKey, MetricSummary> summaries = new ConcurrentHashMap<>();

    public MicrometerMetricFactory(final MeterRegistry registry) {
        this.registry = Objects.requireNonNull(registry, "registry");
    }

    @Override
    public MetricCounter counter(final String name, final String description) {
        return counter(name, description, MetricTags.empty());
    }

    @Override
    public MetricCounter counter(final String name, final String description, final MetricTags tags) {
        final MeterKey key = new MeterKey(name, tags);
        return counters.computeIfAbsent(key, ignored -> {
            final Counter counter = Counter.builder(name)
                    .description(description)
                    .tags(tags.keyValues())
                    .register(registry);
            return new MicrometerCounter(counter);
        });
    }

    @Override
    public MetricTimer timer(final String name, final String description) {
        return timer(name, description, MetricTags.empty());
    }

    @Override
    public MetricTimer timer(final String name, final String description, final MetricTags tags) {
        final MeterKey key = new MeterKey(name, tags);
        return timers.computeIfAbsent(key, ignored -> {
            final Timer timer = Timer.builder(name)
                    .description(description)
                    .publishPercentileHistogram()
                    .tags(tags.keyValues())
                    .register(registry);
            return new MicrometerTimer(registry, timer);
        });
    }

    @Override
    public MetricSummary summary(final String name, final String description) {
        return summary(name, description, MetricTags.empty());
    }

    @Override
    public MetricSummary summary(final String name, final String description, final MetricTags tags) {
        final MeterKey key = new MeterKey(name, tags);
        return summaries.computeIfAbsent(key, ignored -> {
            final DistributionSummary summary = DistributionSummary.builder(name)
                    .description(description)
                    .publishPercentileHistogram()
                    .tags(tags.keyValues())
                    .register(registry);
            return new MicrometerSummary(summary);
        });
    }

    private static final class MeterKey {
        private final String name;
        private final String[] tags;

        private MeterKey(final String name, final MetricTags tags) {
            this.name = Objects.requireNonNull(name, "name");
            this.tags = tags.keyValues();
        }

        @Override
        public boolean equals(final Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof MeterKey)) {
                return false;
            }
            final MeterKey that = (MeterKey) other;
            return name.equals(that.name) && Arrays.equals(tags, that.tags);
        }

        @Override
        public int hashCode() {
            return 31 * name.hashCode() + Arrays.hashCode(tags);
        }
    }

    private static final class MicrometerCounter implements MetricCounter {
        private final Counter delegate;

        private MicrometerCounter(final Counter delegate) {
            this.delegate = delegate;
        }

        @Override
        public void increment() {
            delegate.increment();
        }

        @Override
        public void add(final double amount) {
            delegate.increment(amount);
        }
    }

    private static final class MicrometerTimer implements MetricTimer {
        private final MeterRegistry registry;
        private final Timer delegate;

        private MicrometerTimer(final MeterRegistry registry, final Timer delegate) {
            this.registry = registry;
            this.delegate = delegate;
        }

        @Override
        public void record(final long amount, final TimeUnit unit) {
            delegate.record(amount, unit);
        }

        @Override
        public Sample start() {
            final Timer.Sample sample = Timer.start(registry);
            return () -> sample.stop(delegate);
        }
    }

    private static final class MicrometerSummary implements MetricSummary {
        private final DistributionSummary delegate;

        private MicrometerSummary(final DistributionSummary delegate) {
            this.delegate = delegate;
        }

        @Override
        public void record(final double amount) {
            delegate.record(amount);
        }
    }
}
