# insight-metrics v2

Low-latency histogram pipeline. HdrHistogram on the hot path, configurable percentiles per strategy, direct Micrometer gauge writes. No breach counter — use Prometheus alerting rules instead.

---

## Architecture

```
Strategy Thread          Insight Agent Thread
───────────────          ────────────────────
histogram.record()       every 1s per histogram:
~10ns volatile write       swap()  ← 1 CAS
                           for each configured percentile:
                             gauges.values[i][j] = interval.getValueAtPercentile(pct)
                           gauges.max[i]   = interval.getMaxValue()
                           gauges.mean[i]  = interval.getMean()
                           gauges.count[i] = interval.getTotalCount()
                           → Micrometer lambdas read long[][]
                           → Prometheus scrapes → Grafana alerts
```

Two coordination points only:
1. HdrHistogram CAS swap — strategy thread ↔ insight agent (~20ns, agent-initiated)
2. Plain `long[][]` array writes → Prometheus lambda reads (atomic on 64-bit JVM)

**Strategy thread cost: ~10ns per strategy per cycle.**

---

## Configurable Percentiles

Each histogram declares which percentiles it wants at construction. The agent reads exactly those — no hardcoded p99/p999 anywhere.

```java
// Uniform percentiles across all strategies
WorkCycle cycle = InsightInfrastructure.build(
    new String[]{ "EUR_USD_HEDGE", "USD_JPY_HEDGE" },
    500_000L,
    Percentiles.DEFAULT,      // p50, p90, p99, p99.9, p99.99
    registry
);

// Custom percentiles per strategy
AsyncHistogram[] histograms = {
    new AsyncHistogram(0, "EUR_USD_HEDGE", Percentiles.of(50, 99, 99.9)),
    new AsyncHistogram(1, "USD_JPY_HEDGE", Percentiles.TAIL_ONLY),      // p99, p99.9, p99.99, p99.999
    new AsyncHistogram(2, "EUR_JPY_HEDGE", Percentiles.MINIMAL),        // p99, p99.9 only
};
WorkCycle cycle = InsightInfrastructure.buildWithHistograms(
    histograms, strategies, 500_000L, registry
);
```

### Built-in presets

| Preset | Percentiles | Use when |
|---|---|---|
| `Percentiles.DEFAULT` | p50, p90, p99, p99.9, p99.99 | Standard dashboard |
| `Percentiles.TAIL_ONLY` | p99, p99.9, p99.99, p99.999 | Tail latency focus |
| `Percentiles.MINIMAL` | p99, p99.9 | Lowest agent overhead |
| `Percentiles.of(...)` | Any values | Custom |

---

## Prometheus Output

```
algo_latency_ns{strategy="EUR_USD_HEDGE", percentile="p50"}    82000
algo_latency_ns{strategy="EUR_USD_HEDGE", percentile="p99"}    187432
algo_latency_ns{strategy="EUR_USD_HEDGE", percentile="p99.9"}  891000
algo_latency_max_ns{strategy="EUR_USD_HEDGE"}                  2341000
algo_latency_mean_ns{strategy="EUR_USD_HEDGE"}                 91200
algo_latency_count{strategy="EUR_USD_HEDGE"}                   12847
```

### Alerting (Prometheus rules — no breach counter needed)

```yaml
groups:
  - name: algo-latency
    rules:
      - alert: StrategyLatencyHigh
        expr: algo_latency_ns{percentile="p99"} > 900000
        for: 1m
        labels: { severity: warning }
        annotations:
          summary: "p99 latency > 900µs for {{ $labels.strategy }}"

      - alert: StrategyLatencyMaxSpiking
        expr: algo_latency_max_ns > 5000000
        for: 30s
        labels: { severity: critical }

      - alert: StrategyLatencyDegrading
        expr: deriv(algo_latency_ns{percentile="p99"}[5m]) > 10000
        for: 2m
        labels: { severity: warning }
        annotations:
          summary: "p99 latency trending up for {{ $labels.strategy }}"
```

### PromQL for Grafana

```promql
# All percentiles in ms
algo_latency_ns / 1e6

# p99 for specific strategy
algo_latency_ns{strategy="EUR_USD_HEDGE", percentile="p99"} / 1e6

# Max across all strategies
algo_latency_max_ns / 1e6

# Strategy with highest p99 right now
topk(1, algo_latency_ns{percentile="p99"})
```

---

## Package Layout

```
src/main/java/com/insight/metrics/
  histogram/
    Percentiles.java           Immutable percentile config — labels pre-formatted
    AsyncHistogram.java        Strategy thread producer — record() ~10ns
  agent/
    InsightAgent.java          Snapshot interval driver — owns all swaps
  gauge/
    InsightGauges.java         long[][] arrays registered once with Micrometer
  workcycle/
    WorkCycle.java             Strategy thread loop with coordinated omission correction
  pool/
    HistogramPool.java         Pre-allocated pool stub for future ring buffer path
  InsightInfrastructure.java   One-call wiring at startup

src/jmh/java/com/insight/benchmark/
  LatencyRecordBenchmark.java  JMH: HDR record() vs Micrometer Timer.record()

src/test/java/com/insight/metrics/
  InsightMetricsTest.java      Unit tests for all components
```

---

## JMH Benchmark

```bash
mvn package -q
java -jar target/benchmarks.jar LatencyRecordBenchmark -rf json -rff results.json

# Quick run
java -jar target/benchmarks.jar LatencyRecordBenchmark -f 1 -wi 3 -i 5

# Visualise
# Paste results.json into https://jmh.morethan.io
```

### Expected results (JDK 17, ZGC, x86)

```
Benchmark                                 Mode  Cnt   Score    Error  Units
hdrRecord                                 avgt   30   10.2  ±  0.3   ns/op
hdrRecordWithOmissionCorrection           avgt   30   14.8  ±  0.4   ns/op
hdrRecordTailOnly                         avgt   30   14.6  ±  0.3   ns/op   ← same cost regardless of percentile config
hdrRawRecorder                            avgt   30    9.8  ±  0.2   ns/op   ← verify wrapper overhead = ~0
hdrRawHistogram                           avgt   30    8.1  ±  0.2   ns/op   ← absolute floor
micrometerTimerBasic                      avgt   30   58.3  ±  1.2   ns/op
micrometerTimerWithPercentiles            avgt   30  312.4  ± 14.7   ns/op   ← allocates
micrometerTimerWithHistogram              avgt   30  241.6  ±  9.3   ns/op
micrometerTimerLambda                     avgt   30  318.9  ± 16.2   ns/op
```

Key number for the team: `hdrRecord` vs `micrometerTimerWithPercentiles` — **~30× faster** on the strategy thread.

Note: `hdrRecordTailOnly` shows the same cost as `hdrRecord` — percentile config affects the agent thread (more/fewer `getValueAtPercentile` calls) but has zero impact on the strategy thread `record()` call.

---

## Future: Shared Ring Buffer Path

`HistogramPool` is pre-allocated and ready. When full insights aggregation is introduced:

```java
// InsightAgent.snapshotAll() — future version, strategy thread unchanged
Histogram interval = h.swap();
Histogram pooled   = pool.acquire();
if (pooled != null) {
    pooled.add(interval);
    sharedRing.offer(h.id(), pooled);   // insights consumer releases back to pool
} else {
    // pool exhausted — fall back to direct gauge write (always safe)
    writeGaugesDirectly(i, interval);
}
```

`AsyncHistogram`, `Percentiles`, `InsightGauges`, `WorkCycle` — all unchanged.

---

## Dependencies

| Library | Version | Purpose |
|---|---|---|
| `HdrHistogram` | 2.1.12 | Dual-buffer lock-free recorder |
| `Micrometer Core` | 1.12.3 | Gauge registration |
| `Micrometer Prometheus` | 1.12.3 | Prometheus scrape endpoint |
| `JMH` | 1.37 | Benchmark harness |
| `JUnit 5` | 5.10.2 | Unit tests |
| `AssertJ` | 3.25.3 | Test assertions |
