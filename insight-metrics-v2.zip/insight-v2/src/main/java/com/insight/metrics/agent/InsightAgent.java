package com.insight.metrics.agent;

import com.insight.metrics.gauge.InsightGauges;
import com.insight.metrics.histogram.AsyncHistogram;
import com.insight.metrics.histogram.Percentiles;
import org.HdrHistogram.Histogram;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * InsightAgent — drives all histogram swaps at a fixed interval.
 *
 * On each interval:
 *   1. swap() each AsyncHistogram — CAS buffer exchange, ~20ns
 *   2. Read the percentiles each histogram declared at construction
 *   3. Write directly into InsightGauges long[][] arrays
 *   4. Prometheus scrapes the arrays via Micrometer gauge lambdas
 *
 * No ring buffer. No codec. No breach counter. No threshold config.
 * Alerting is handled by Prometheus rules on the published gauges.
 *
 * Threading:
 *   snapshotAll() runs on "insight-agent" daemon thread only.
 *   Strategy thread participates only in AsyncHistogram.record() — never here.
 *
 * Future ring buffer path:
 *   When shared insights ring is introduced, replace the direct gauge writes
 *   in snapshotAll() with pool.acquire() + copy + ring.offer(ref).
 *   AsyncHistogram, Percentiles, InsightGauges registration — all unchanged.
 */
public final class InsightAgent {

    private final AsyncHistogram[]         histograms;
    private final InsightGauges            gauges;
    private final long                     intervalNs;
    private final ScheduledExecutorService scheduler;

    /**
     * @param histograms  ordered array — indices must match InsightGauges
     * @param gauges      pre-registered gauge arrays
     * @param intervalNs  snapshot interval in nanoseconds (1_000_000_000L = 1s)
     */
    public InsightAgent(AsyncHistogram[] histograms,
                        InsightGauges    gauges,
                        long             intervalNs) {
        this.histograms = histograms;
        this.gauges     = gauges;
        this.intervalNs = intervalNs;

        this.scheduler = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "insight-agent");
            t.setDaemon(true);
            t.setPriority(Thread.NORM_PRIORITY + 1);
            return t;
        });
    }

    /** Convenience constructor with 1 second default interval. */
    public InsightAgent(AsyncHistogram[] histograms, InsightGauges gauges) {
        this(histograms, gauges, 1_000_000_000L);
    }

    /** Start the snapshot loop. Call once at application startup. */
    public void start() {
        scheduler.scheduleAtFixedRate(
            this::snapshotAll,
            intervalNs,
            intervalNs,
            TimeUnit.NANOSECONDS
        );
    }

    // =========================================================================
    // INSIGHT AGENT THREAD — runs every intervalNs
    // =========================================================================

    private void snapshotAll() {
        for (int i = 0; i < histograms.length; i++) {
            AsyncHistogram h    = histograms[i];
            Percentiles    pcts = h.percentiles();

            // =================================================================
            // THE SWAP — only cross-thread coordination with strategy thread
            // CAS on HdrHistogram internal buffer pointer. ~20ns.
            // After this: interval contains all observations since last swap.
            // Strategy thread immediately writes to fresh buffer.
            // =================================================================
            Histogram interval = h.swap();

            // Read exactly the percentiles this histogram was configured with.
            // No hardcoded p99/p999 — driven entirely by Percentiles config.
            for (int j = 0; j < pcts.size(); j++) {
                gauges.values[i][j] = interval.getValueAtPercentile(pcts.value(j));
            }

            // max, mean, count — always written regardless of percentile config
            gauges.max[i]   = interval.getMaxValue();
            gauges.mean[i]  = (long) interval.getMean();
            gauges.count[i] = interval.getTotalCount();
        }
    }

    /** Stop the agent gracefully. */
    public void stop() {
        scheduler.shutdown();
        try {
            scheduler.awaitTermination(5, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
