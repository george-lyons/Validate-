package com.insight.metrics.histogram;

/**
 * Percentiles — immutable configuration of which percentiles to track.
 *
 * Passed to AsyncHistogram at construction. The agent reads exactly these
 * percentiles on each swap — no hardcoded p50/p99/p999 anywhere in the pipeline.
 *
 * Each percentile is stored as both a double (for HdrHistogram lookup) and
 * a pre-formatted String label (for Micrometer tag — computed once, reused forever).
 *
 * Examples:
 *   Percentiles.of(50, 99, 99.9, 99.99)
 *   Percentiles.DEFAULT    → 50, 90, 99, 99.9, 99.99
 *   Percentiles.TAIL_ONLY  → 99, 99.9, 99.99, 99.999
 */
public final class Percentiles {

    /** Sensible default covering typical latency dashboard needs. */
    public static final Percentiles DEFAULT   = Percentiles.of(50, 90, 99, 99.9, 99.99);

    /** Tail-focused — for strategies where median is irrelevant. */
    public static final Percentiles TAIL_ONLY = Percentiles.of(99, 99.9, 99.99, 99.999);

    /** Minimal — p99 and max only. Lowest agent overhead. */
    public static final Percentiles MINIMAL   = Percentiles.of(99, 99.9);

    private final double[] values;   // e.g. [50.0, 99.0, 99.9, 99.99]
    private final String[] labels;   // e.g. ["p50", "p99", "p99.9", "p99.99"]

    private Percentiles(double[] values) {
        this.values = values;
        this.labels = new String[values.length];
        for (int i = 0; i < values.length; i++) {
            this.labels[i] = formatLabel(values[i]);
        }
    }

    /**
     * Create a Percentiles config from the given percentile values.
     *
     * @param percentiles values in range (0, 100) — e.g. 99.9 for p99.9
     */
    public static Percentiles of(double... percentiles) {
        if (percentiles == null || percentiles.length == 0) {
            throw new IllegalArgumentException("At least one percentile required");
        }
        for (double p : percentiles) {
            if (p <= 0 || p >= 100) {
                throw new IllegalArgumentException(
                    "Percentile must be in range (0, 100), got: " + p);
            }
        }
        double[] copy = percentiles.clone();
        return new Percentiles(copy);
    }

    /** Number of configured percentiles. */
    public int size() {
        return values.length;
    }

    /**
     * Percentile value at index i — passed directly to
     * HdrHistogram.getValueAtPercentile().
     */
    public double value(int i) {
        return values[i];
    }

    /**
     * Micrometer tag label for percentile at index i.
     * Pre-formatted at construction — no allocation in the agent loop.
     * e.g. 99.0 → "p99", 99.9 → "p99.9", 99.99 → "p99.99"
     */
    public String label(int i) {
        return labels[i];
    }

    /** All percentile values — for iteration. */
    public double[] values() {
        return values.clone();
    }

    /** All labels — for iteration. */
    public String[] labels() {
        return labels.clone();
    }

    // Format 99.0 → "p99", 99.9 → "p99.9", 50.0 → "p50"
    private static String formatLabel(double p) {
        if (p == Math.floor(p)) {
            return "p" + (int) p;
        }
        // Strip trailing zeros: 99.90 → "p99.9"
        String s = String.valueOf(p);
        return "p" + (s.endsWith(".0") ? s.substring(0, s.length() - 2) : s);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("Percentiles[");
        for (int i = 0; i < labels.length; i++) {
            if (i > 0) sb.append(", ");
            sb.append(labels[i]);
        }
        return sb.append("]").toString();
    }
}
