package com.insight.metrics;

import com.insight.metrics.agent.InsightAgent;
import com.insight.metrics.gauge.InsightGauges;
import com.insight.metrics.histogram.AsyncHistogram;
import com.insight.metrics.histogram.Percentiles;
import com.insight.metrics.pool.HistogramPool;
import com.insight.metrics.workcycle.WorkCycle;
import io.micrometer.core.instrument.MeterRegistry;

/**
 * InsightInfrastructure — assembles and wires all components at startup.
 *
 * Usage — uniform percentiles across all strategies:
 *
 *   WorkCycle cycle = InsightInfrastructure.build(
 *       new String[]{ "EUR_USD_HEDGE", "USD_JPY_HEDGE", "EUR_JPY_HEDGE" },
 *       500_000L,                    // 500µs target cycle
 *       Percentiles.DEFAULT,         // p50, p90, p99, p99.9, p99.99
 *       meterRegistry
 *   );
 *
 * Usage — custom percentiles per strategy:
 *
 *   AsyncHistogram[] histograms = {
 *       new AsyncHistogram(0, "EUR_USD_HEDGE", Percentiles.of(50, 99, 99.9)),
 *       new AsyncHistogram(1, "USD_JPY_HEDGE", Percentiles.TAIL_ONLY),
 *       new AsyncHistogram(2, "EUR_JPY_HEDGE", Percentiles.MINIMAL),
 *   };
 *   WorkCycle cycle = InsightInfrastructure.buildWithHistograms(
 *       histograms, myStrategies, 500_000L, meterRegistry
 *   );
 *
 * Alerting:
 *   Configure Prometheus alerting rules on algo_latency_ns and algo_latency_max_ns.
 *   No breach counter or threshold config needed in this library.
 *
 *   Example Prometheus alert rule:
 *     - alert: StrategyLatencyHigh
 *       expr: algo_latency_ns{percentile="p99"} > 900000
 *       for: 1m
 *       labels: { severity: warning }
 */
public final class InsightInfrastructure {

    /**
     * Build with uniform percentiles across all strategies.
     * Placeholder strategy implementations — caller replaces with real logic.
     */
    public static WorkCycle build(String[]      strategyNames,
                                  long          targetCycleNs,
                                  Percentiles   percentiles,
                                  MeterRegistry registry) {

        int n = strategyNames.length;
        AsyncHistogram[] histograms = new AsyncHistogram[n];
        for (int i = 0; i < n; i++) {
            histograms[i] = new AsyncHistogram(i, strategyNames[i], percentiles);
        }

        WorkCycle.Strategy[] strategies = new WorkCycle.Strategy[n];
        for (int i = 0; i < n; i++) {
            strategies[i] = () -> {};   // replace with real strategy
        }

        return wire(histograms, strategies, targetCycleNs, registry);
    }

    /**
     * Build with caller-supplied histograms (custom percentiles per strategy)
     * and real strategy implementations.
     */
    public static WorkCycle buildWithHistograms(AsyncHistogram[]       histograms,
                                                WorkCycle.Strategy[]   strategies,
                                                long                   targetCycleNs,
                                                MeterRegistry          registry) {
        return wire(histograms, strategies, targetCycleNs, registry);
    }

    // =========================================================================
    // Internal wiring
    // =========================================================================

    private static WorkCycle wire(AsyncHistogram[]     histograms,
                                  WorkCycle.Strategy[] strategies,
                                  long                 targetCycleNs,
                                  MeterRegistry        registry) {

        // 1. Gauges — registered once, Micrometer/Prometheus wired here
        InsightGauges gauges = new InsightGauges(histograms, registry);

        // 2. Pool — pre-allocated for future ring buffer path, not used today
        HistogramPool pool = new HistogramPool(2 * histograms.length, 10_000_000_000L, 3);

        // 3. Agent — starts background snapshot loop
        InsightAgent agent = new InsightAgent(histograms, gauges);
        agent.start();

        // 4. WorkCycle — returned; caller owns the strategy thread
        return new WorkCycle(strategies, histograms, targetCycleNs);
    }

    private InsightInfrastructure() {}
}
