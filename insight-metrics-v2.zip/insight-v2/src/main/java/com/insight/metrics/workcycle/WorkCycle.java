package com.insight.metrics.workcycle;

import com.insight.metrics.histogram.AsyncHistogram;

/**
 * WorkCycle — strategy thread entry point.
 *
 * Loops N strategies sequentially each cycle. Records per-strategy elapsed
 * time into AsyncHistogram with coordinated omission correction.
 *
 * Only metrics call on this thread: histograms[i].record(elapsed, expectedCycleNs)
 * → single volatile write, ~10ns, no allocation.
 */
public final class WorkCycle implements Runnable {

    @FunctionalInterface
    public interface Strategy {
        void onCycle();
    }

    private final Strategy[]       strategies;
    private final AsyncHistogram[] histograms;      // parallel array
    private final long             expectedCycleNs;
    private volatile boolean       running = true;

    public WorkCycle(Strategy[]       strategies,
                     AsyncHistogram[] histograms,
                     long             expectedCycleNs) {
        if (strategies.length != histograms.length) {
            throw new IllegalArgumentException(
                "strategies and histograms must be same length");
        }
        this.strategies      = strategies;
        this.histograms      = histograms;
        this.expectedCycleNs = expectedCycleNs;
    }

    @Override
    public void run() {
        while (running && !Thread.currentThread().isInterrupted()) {
            runOneCycle();
        }
    }

    /**
     * One complete work cycle.
     * Fixed array loop — no Iterator, no autoboxing, no allocation.
     */
    public void runOneCycle() {
        for (int i = 0; i < strategies.length; i++) {
            final long start   = System.nanoTime();
            strategies[i].onCycle();
            final long elapsed = System.nanoTime() - start;

            // Coordinated omission correction:
            // If strategies[i-1] overran, strategies[i] started late.
            // Fills in implied wait so p99 reflects true end-to-end latency.
            histograms[i].record(elapsed, expectedCycleNs);
        }
    }

    public void stop() { running = false; }
}
