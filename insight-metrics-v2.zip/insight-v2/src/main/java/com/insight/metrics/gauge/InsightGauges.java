package com.insight.metrics.gauge;

import com.insight.metrics.histogram.AsyncHistogram;
import com.insight.metrics.histogram.Percentiles;
import io.micrometer.core.instrument.Gauge;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Tags;

/**
 * InsightGauges — long[][] arrays registered with Micrometer once at startup.
 *
 * Scales to any number of histograms each with any set of percentiles.
 * No hardcoded p50/p99/p999 — each histogram's Percentiles config drives
 * exactly which gauges are registered and which labels they carry.
 *
 * Layout:
 *   values[histogramIdx][percentileIdx]  — percentile values per histogram
 *   max[histogramIdx]                    — always tracked regardless of percentiles
 *   mean[histogramIdx]                   — always tracked
 *   count[histogramIdx]                  — always tracked
 *
 * Prometheus output example for Percentiles.of(50, 99, 99.9):
 *   algo_latency_ns{strategy="EUR_USD_HEDGE", percentile="p50"}   82000
 *   algo_latency_ns{strategy="EUR_USD_HEDGE", percentile="p99"}   187432
 *   algo_latency_ns{strategy="EUR_USD_HEDGE", percentile="p99.9"} 891000
 *   algo_latency_max_ns{strategy="EUR_USD_HEDGE"}                 2341000
 *   algo_latency_mean_ns{strategy="EUR_USD_HEDGE"}                91200
 *   algo_latency_count{strategy="EUR_USD_HEDGE"}                  12847
 *
 * Threading:
 *   values[i][j] = v  — insight agent thread writes
 *   () -> values[i][j] — Prometheus scrape thread reads via lambda
 *   Long writes are atomic on 64-bit JVM — no synchronisation needed.
 */
public final class InsightGauges {

    // values[histogramIdx][percentileIdx] — written by agent, read by scrape
    final long[][] values;
    final long[]   max;
    final long[]   mean;
    final long[]   count;

    /**
     * Registers all gauges with Micrometer at construction.
     * Called once at startup. Never called again.
     *
     * Each histogram's Percentiles config drives which gauges are registered —
     * different histograms can have completely different percentile sets.
     */
    public InsightGauges(AsyncHistogram[] histograms, MeterRegistry registry) {
        int n    = histograms.length;
        values   = new long[n][];
        max      = new long[n];
        mean     = new long[n];
        count    = new long[n];

        for (int i = 0; i < n; i++) {
            AsyncHistogram h    = histograms[i];
            Percentiles    pcts = h.percentiles();
            int            np   = pcts.size();

            values[i] = new long[np];

            Tags strategyTag = Tags.of("strategy", h.name());

            // Register one gauge per configured percentile
            // Label comes from Percentiles.label(j) — pre-formatted at construction
            for (int j = 0; j < np; j++) {
                final int hi = i;
                final int pi = j;
                Tags tags = strategyTag.and("percentile", pcts.label(j));

                Gauge.builder("algo.latency.ns", () -> (double) values[hi][pi])
                     .tags(tags)
                     .description("Strategy latency percentile in nanoseconds")
                     .register(registry);
            }

            // Max, mean, count — always registered, no percentile tag
            final int idx = i;
            Gauge.builder("algo.latency.max.ns",  () -> (double) max[idx])
                 .tags(strategyTag)
                 .description("Strategy max latency in nanoseconds")
                 .register(registry);

            Gauge.builder("algo.latency.mean.ns", () -> (double) mean[idx])
                 .tags(strategyTag)
                 .description("Strategy mean latency in nanoseconds")
                 .register(registry);

            Gauge.builder("algo.latency.count",   () -> (double) count[idx])
                 .tags(strategyTag)
                 .description("Strategy observation count in last interval")
                 .register(registry);
        }
    }
}
