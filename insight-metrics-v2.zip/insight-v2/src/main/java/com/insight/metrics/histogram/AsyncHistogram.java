package com.insight.metrics.histogram;

import org.HdrHistogram.Histogram;
import org.HdrHistogram.Recorder;

/**
 * AsyncHistogram — producer-side histogram for the strategy thread.
 *
 * Configurable percentiles: each histogram declares which percentiles it
 * wants tracked at construction. The insight agent reads exactly those
 * percentiles on each swap — no hardcoded values anywhere in the pipeline.
 *
 * Breach detection removed: use Prometheus alerting rules on
 * algo_latency_ns{percentile="p99"} instead. More flexible, no AtomicLong
 * on the hot path, no threshold config to maintain here.
 *
 * Threading contract:
 *   record()  — called ONLY on strategy (work cycle) thread
 *   swap()    — called ONLY on insight agent thread
 *
 * Cross-thread coordination: one CAS inside HdrHistogram.Recorder on swap().
 * Strategy thread participates only in record() — one volatile write, ~10ns.
 */
public final class AsyncHistogram {

    private final int         id;
    private final String      name;
    private final Percentiles percentiles;
    private final Recorder    recorder;
    private final Histogram   intervalHistogram;   // pre-allocated; agent owns after swap

    /**
     * @param id           numeric ID — used as array index in InsightGauges
     * @param name         human-readable label for Micrometer strategy tag
     * @param percentiles  which percentiles to publish — e.g. Percentiles.DEFAULT
     */
    public AsyncHistogram(int id, String name, Percentiles percentiles) {
        this.id               = id;
        this.name             = name;
        this.percentiles      = percentiles;
        this.recorder         = new Recorder(10_000_000_000L, 3);
        this.intervalHistogram = new Histogram(10_000_000_000L, 3);
    }

    /** Convenience constructor using DEFAULT percentiles. */
    public AsyncHistogram(int id, String name) {
        this(id, name, Percentiles.DEFAULT);
    }

    // =========================================================================
    // STRATEGY THREAD — only API called on hot path
    // =========================================================================

    /**
     * Record a single observation.
     * Single volatile write into HdrHistogram dual buffer. ~10ns. No allocation.
     */
    public void record(long valueNs) {
        recorder.recordValue(valueNs);
    }

    /**
     * Record with coordinated omission correction.
     * Use when strategies run sequentially — fills in implied waiting time
     * if a slow predecessor delayed this strategy's scheduled start.
     *
     * @param valueNs            actual elapsed nanoseconds
     * @param expectedIntervalNs target cycle time in nanoseconds
     */
    public void record(long valueNs, long expectedIntervalNs) {
        recorder.recordValueWithExpectedInterval(valueNs, expectedIntervalNs);
    }

    // =========================================================================
    // INSIGHT AGENT THREAD
    // =========================================================================

    /**
     * Atomically swap HdrHistogram's internal buffers.
     * Returns completed interval — all observations since previous swap().
     * Strategy thread immediately writes to fresh buffer after this call.
     * Cross-thread cost: one CAS + memory fence. ~20ns.
     */
    public Histogram swap() {
        recorder.getIntervalHistogram(intervalHistogram);
        return intervalHistogram;
    }

    public int         id()          { return id; }
    public String      name()        { return name; }
    public Percentiles percentiles() { return percentiles; }
}
