package com.insight.metrics.pool;

import org.HdrHistogram.Histogram;

import java.util.concurrent.ArrayBlockingQueue;

/**
 * HistogramPool — pre-allocated pool for the future shared ring buffer path.
 *
 * Not used today. Exists so the ring buffer introduction later requires
 * no new allocation infrastructure — just wire this in.
 *
 * Future usage in InsightAgent.snapshotAll():
 *   Histogram interval = h.swap();
 *   Histogram pooled   = pool.acquire();
 *   if (pooled != null) {
 *       pooled.add(interval);
 *       sharedRing.offer(h.id(), pooled);   // insights consumer releases back
 *   } else {
 *       // pool exhausted — fall back to direct gauge write (already done above)
 *   }
 *
 * Threading:
 *   acquire() — insight agent thread
 *   release() — insights consumer thread (after ring introduction)
 */
public final class HistogramPool {

    private final ArrayBlockingQueue<Histogram> pool;
    private final int                           capacity;

    /**
     * @param capacity    number of pre-allocated slots — recommend 2 × histogram count
     * @param maxValueNs  must match AsyncHistogram (10_000_000_000L)
     * @param sigFigures  must match AsyncHistogram (3)
     */
    public HistogramPool(int capacity, long maxValueNs, int sigFigures) {
        this.capacity = capacity;
        this.pool     = new ArrayBlockingQueue<>(capacity);
        for (int i = 0; i < capacity; i++) {
            pool.offer(new Histogram(maxValueNs, sigFigures));
        }
    }

    /** Acquire a slot. Returns null if pool exhausted — caller should degrade gracefully. */
    public Histogram acquire() {
        return pool.poll();
    }

    /** Return a slot after consumer is done. Resets histogram before return. */
    public void release(Histogram h) {
        h.reset();
        pool.offer(h);
    }

    public int capacity()  { return capacity; }
    public int available() { return pool.size(); }
}
