package com.insight.metrics;

import com.insight.metrics.agent.InsightAgent;
import com.insight.metrics.gauge.InsightGauges;
import com.insight.metrics.histogram.AsyncHistogram;
import com.insight.metrics.histogram.Percentiles;
import io.micrometer.core.instrument.Gauge;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;
import org.HdrHistogram.Histogram;
import org.junit.jupiter.api.Test;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import static org.assertj.core.api.Assertions.*;

// =============================================================================
// Percentiles tests
// =============================================================================

class PercentilesTest {

    @Test
    void labelsFormattedCorrectly() {
        Percentiles p = Percentiles.of(50, 99, 99.9, 99.99, 99.999);
        assertThat(p.label(0)).isEqualTo("p50");
        assertThat(p.label(1)).isEqualTo("p99");
        assertThat(p.label(2)).isEqualTo("p99.9");
        assertThat(p.label(3)).isEqualTo("p99.99");
        assertThat(p.label(4)).isEqualTo("p99.999");
    }

    @Test
    void defaultHasFivePercentiles() {
        assertThat(Percentiles.DEFAULT.size()).isEqualTo(5);
    }

    @Test
    void tailOnlyHasFourPercentiles() {
        assertThat(Percentiles.TAIL_ONLY.size()).isEqualTo(4);
    }

    @Test
    void minimalHasTwoPercentiles() {
        assertThat(Percentiles.MINIMAL.size()).isEqualTo(2);
    }

    @Test
    void valuesOutOfRangeThrow() {
        assertThatThrownBy(() -> Percentiles.of(0))
            .isInstanceOf(IllegalArgumentException.class);
        assertThatThrownBy(() -> Percentiles.of(100))
            .isInstanceOf(IllegalArgumentException.class);
        assertThatThrownBy(() -> Percentiles.of())
            .isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    void valuesCloneIsIndependent() {
        Percentiles p    = Percentiles.of(50, 99);
        double[]    vals = p.values();
        vals[0] = 1.0;   // mutate clone
        assertThat(p.value(0)).isEqualTo(50.0);   // original unchanged
    }
}

// =============================================================================
// AsyncHistogram tests
// =============================================================================

class AsyncHistogramTest {

    @Test
    void recordedValuesReturnedOnSwap() {
        AsyncHistogram h = new AsyncHistogram(0, "test", Percentiles.DEFAULT);
        h.record(100_000L);
        h.record(200_000L);
        h.record(300_000L);

        Histogram interval = h.swap();
        assertThat(interval.getTotalCount()).isEqualTo(3);
        assertThat(interval.getMaxValue()).isGreaterThanOrEqualTo(300_000L);
    }

    @Test
    void swapClearsInterval() {
        AsyncHistogram h = new AsyncHistogram(0, "test", Percentiles.DEFAULT);
        h.record(100_000L);
        h.swap();

        h.record(999_000L);
        Histogram second = h.swap();

        assertThat(second.getTotalCount()).isEqualTo(1);
        assertThat(second.getMaxValue()).isGreaterThanOrEqualTo(999_000L);
    }

    @Test
    void coordinatedOmissionCorrectionRecordsImpliedValues() {
        AsyncHistogram h = new AsyncHistogram(0, "test", Percentiles.MINIMAL);
        // 1ms actual, 500µs expected — should fill in one extra implied value
        h.record(1_000_000L, 500_000L);

        Histogram interval = h.swap();
        // With correction, count should be > 1 (implied intermediate value filled in)
        assertThat(interval.getTotalCount()).isGreaterThanOrEqualTo(1);
        assertThat(interval.getMaxValue()).isGreaterThanOrEqualTo(1_000_000L);
    }

    @Test
    void defaultConstructorUsesDefaultPercentiles() {
        AsyncHistogram h = new AsyncHistogram(0, "test");
        assertThat(h.percentiles()).isSameAs(Percentiles.DEFAULT);
    }

    @Test
    void swapFromDifferentThreadIsThreadSafe() throws InterruptedException {
        AsyncHistogram h     = new AsyncHistogram(0, "test", Percentiles.MINIMAL);
        CountDownLatch ready = new CountDownLatch(1);
        CountDownLatch done  = new CountDownLatch(1);

        Thread writer = new Thread(() -> {
            ready.countDown();
            for (int i = 0; i < 1000; i++) h.record(100_000L + i);
            done.countDown();
        });
        writer.start();
        ready.await();

        Histogram first = h.swap();     // mid-flight swap
        done.await(2, TimeUnit.SECONDS);
        Histogram second = h.swap();    // drain remainder

        assertThat(first.getTotalCount() + second.getTotalCount()).isEqualTo(1000);
    }
}

// =============================================================================
// InsightGauges tests
// =============================================================================

class InsightGaugesTest {

    @Test
    void registersOneGaugePerPercentilePerHistogram() {
        AsyncHistogram[] histograms = {
            new AsyncHistogram(0, "strat-a", Percentiles.of(99, 99.9)),
            new AsyncHistogram(1, "strat-b", Percentiles.of(50, 90, 99))
        };
        MeterRegistry registry = new SimpleMeterRegistry();
        new InsightGauges(histograms, registry);

        // strat-a: 2 percentile gauges + max + mean + count = 5
        // strat-b: 3 percentile gauges + max + mean + count = 6
        // total = 11
        assertThat(registry.getMeters()).hasSize(11);
    }

    @Test
    void gaugeReadsCurrentArrayValue() throws InterruptedException {
        AsyncHistogram[] histograms = {
            new AsyncHistogram(0, "strat-a", Percentiles.MINIMAL)   // p99, p99.9
        };
        MeterRegistry registry = new SimpleMeterRegistry();
        InsightGauges gauges   = new InsightGauges(histograms, registry);

        gauges.values[0][0] = 187_432L;   // write p99
        gauges.max[0]       = 2_341_000L;

        // Find the p99 gauge and assert it reads the written value
        Gauge p99Gauge = registry.find("algo.latency.ns")
            .tag("strategy", "strat-a")
            .tag("percentile", "p99")
            .gauge();

        assertThat(p99Gauge).isNotNull();
        assertThat(p99Gauge.value()).isEqualTo(187_432.0);
    }

    @Test
    void differentHistogramsCanHaveDifferentPercentileConfigs() {
        AsyncHistogram[] histograms = {
            new AsyncHistogram(0, "fast",  Percentiles.MINIMAL),    // 2 percentiles
            new AsyncHistogram(1, "slow",  Percentiles.DEFAULT),    // 5 percentiles
            new AsyncHistogram(2, "tail",  Percentiles.TAIL_ONLY)   // 4 percentiles
        };
        MeterRegistry registry = new SimpleMeterRegistry();
        InsightGauges gauges   = new InsightGauges(histograms, registry);

        assertThat(gauges.values[0]).hasSize(2);
        assertThat(gauges.values[1]).hasSize(5);
        assertThat(gauges.values[2]).hasSize(4);
    }
}

// =============================================================================
// InsightAgent tests
// =============================================================================

class InsightAgentTest {

    @Test
    void agentWritesAllConfiguredPercentiles() throws InterruptedException {
        AsyncHistogram[] histograms = {
            new AsyncHistogram(0, "strat-a", Percentiles.of(50, 99, 99.9))
        };
        MeterRegistry registry = new SimpleMeterRegistry();
        InsightGauges gauges   = new InsightGauges(histograms, registry);

        histograms[0].record(100_000L);
        histograms[0].record(200_000L);
        histograms[0].record(500_000L);

        InsightAgent agent = new InsightAgent(histograms, gauges, 100_000_000L);
        agent.start();
        Thread.sleep(250);
        agent.stop();

        // All three percentile slots should be populated
        assertThat(gauges.values[0][0]).isGreaterThan(0L);   // p50
        assertThat(gauges.values[0][1]).isGreaterThan(0L);   // p99
        assertThat(gauges.values[0][2]).isGreaterThan(0L);   // p99.9
        assertThat(gauges.max[0]).isGreaterThanOrEqualTo(500_000L);
        assertThat(gauges.count[0]).isGreaterThan(0L);
    }

    @Test
    void agentClearsIntervalBetweenSnapshots() throws InterruptedException {
        AsyncHistogram[] histograms = {
            new AsyncHistogram(0, "strat-a", Percentiles.MINIMAL)
        };
        MeterRegistry registry = new SimpleMeterRegistry();
        InsightGauges gauges   = new InsightGauges(histograms, registry);

        InsightAgent agent = new InsightAgent(histograms, gauges, 100_000_000L);
        agent.start();

        histograms[0].record(999_000L);
        Thread.sleep(200);
        long maxAfterFirst = gauges.max[0];

        // Nothing recorded in second interval
        Thread.sleep(200);
        long countAfterSecond = gauges.count[0];

        agent.stop();

        assertThat(maxAfterFirst).isGreaterThanOrEqualTo(999_000L);
        assertThat(countAfterSecond).isEqualTo(0L);
    }
}
