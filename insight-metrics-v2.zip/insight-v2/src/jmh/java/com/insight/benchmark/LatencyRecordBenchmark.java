package com.insight.benchmark;

import com.insight.metrics.histogram.AsyncHistogram;
import com.insight.metrics.histogram.Percentiles;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Timer;
import io.micrometer.prometheusmetrics.PrometheusConfig;
import io.micrometer.prometheusmetrics.PrometheusMeterRegistry;
import org.HdrHistogram.Histogram;
import org.HdrHistogram.Recorder;
import org.openjdk.jmh.annotations.*;
import org.openjdk.jmh.infra.Blackhole;
import org.openjdk.jmh.runner.Runner;
import org.openjdk.jmh.runner.RunnerException;
import org.openjdk.jmh.runner.options.Options;
import org.openjdk.jmh.runner.options.OptionsBuilder;

import java.util.concurrent.TimeUnit;

/**
 * JMH Benchmark — HDR record() vs Micrometer Timer.record() on strategy thread.
 *
 * Measures the cost of the single metrics call per strategy per cycle.
 *
 * Build and run:
 *   mvn package -q
 *   java -jar target/benchmarks.jar LatencyRecordBenchmark -rf json -rff results.json
 *
 * Quick run (fewer forks/iterations):
 *   java -jar target/benchmarks.jar LatencyRecordBenchmark -f 1 -wi 3 -i 5
 *
 * HDR variants only:
 *   java -jar target/benchmarks.jar ".*hdr.*"
 *
 * Micrometer variants only:
 *   java -jar target/benchmarks.jar ".*micrometer.*"
 *
 * View results visually:
 *   Paste results.json into https://jmh.morethan.io
 *
 * Expected ballpark (JDK 17, ZGC, x86):
 *   hdrRecord                          ~10ns
 *   hdrRecordWithOmissionCorrection    ~15ns
 *   micrometerTimerBasic               ~60ns
 *   micrometerTimerWithPercentiles    ~300ns   ← allocates
 *   micrometerTimerWithHistogram      ~250ns
 */
@BenchmarkMode(Mode.AverageTime)
@OutputTimeUnit(TimeUnit.NANOSECONDS)
@State(Scope.Thread)
@Warmup(iterations = 5, time = 3, timeUnit = TimeUnit.SECONDS)
@Measurement(iterations = 10, time = 3, timeUnit = TimeUnit.SECONDS)
@Fork(value = 3, jvmArgs = {
    "-XX:+UseZGC",
    "-Xms512m", "-Xmx512m",
    "-XX:+AlwaysPreTouch",
    "-XX:+DisableExplicitGC"
})
public class LatencyRecordBenchmark {

    private static final long SAMPLE_NS        = 100_000L;   // 100µs — realistic strategy time
    private static final long EXPECTED_CYCLE   = 500_000L;   // 500µs target cycle

    // HDR
    private AsyncHistogram asyncHistogram;
    private AsyncHistogram asyncHistogramTailOnly;
    private Recorder       rawRecorder;
    private Histogram      rawHistogram;

    // Micrometer
    private MeterRegistry registry;
    private Timer         basicTimer;
    private Timer         percentilesTimer;
    private Timer         histogramTimer;

    @Setup(Level.Trial)
    public void setup() {
        asyncHistogram         = new AsyncHistogram(0, "strategy-default",   Percentiles.DEFAULT);
        asyncHistogramTailOnly = new AsyncHistogram(1, "strategy-tail-only", Percentiles.TAIL_ONLY);
        rawRecorder            = new Recorder(10_000_000_000L, 3);
        rawHistogram           = new Histogram(10_000_000_000L, 3);

        registry = new PrometheusMeterRegistry(PrometheusConfig.DEFAULT);

        basicTimer = Timer.builder("bench.basic")
            .register(registry);

        percentilesTimer = Timer.builder("bench.percentiles")
            .publishPercentiles(0.5, 0.99, 0.999)
            .register(registry);

        histogramTimer = Timer.builder("bench.histogram")
            .publishPercentileHistogram(true)
            .register(registry);
    }

    // =========================================================================
    // HDR — our design
    // =========================================================================

    /** Our design: AsyncHistogram.record() — DEFAULT percentiles config */
    @Benchmark
    public void hdrRecord() {
        asyncHistogram.record(SAMPLE_NS);
    }

    /** Our design with coordinated omission correction */
    @Benchmark
    public void hdrRecordWithOmissionCorrection() {
        asyncHistogram.record(SAMPLE_NS, EXPECTED_CYCLE);
    }

    /** TAIL_ONLY percentiles config — same record() cost, different agent work */
    @Benchmark
    public void hdrRecordTailOnly() {
        asyncHistogramTailOnly.record(SAMPLE_NS, EXPECTED_CYCLE);
    }

    /** Raw Recorder.recordValue() — verify our wrapper adds nothing */
    @Benchmark
    public void hdrRawRecorder() {
        rawRecorder.recordValue(SAMPLE_NS);
    }

    /** Absolute floor — HdrHistogram bucket write with no dual-buffer overhead */
    @Benchmark
    public void hdrRawHistogram(Blackhole bh) {
        rawHistogram.recordValue(SAMPLE_NS);
        bh.consume(rawHistogram);
    }

    // =========================================================================
    // Micrometer — what the alternative looks like on the strategy thread
    // =========================================================================

    /** Micrometer basic — no percentiles. Not what teams deploy but fair baseline. */
    @Benchmark
    public void micrometerTimerBasic() {
        basicTimer.record(SAMPLE_NS, TimeUnit.NANOSECONDS);
    }

    /**
     * Micrometer with publishPercentiles — what most teams configure.
     * THIS is the number that justifies our design to sceptics.
     * Allocates internally. ~20-30× slower than hdrRecord.
     */
    @Benchmark
    public void micrometerTimerWithPercentiles() {
        percentilesTimer.record(SAMPLE_NS, TimeUnit.NANOSECONDS);
    }

    /** Micrometer with publishPercentileHistogram — full histogram mode */
    @Benchmark
    public void micrometerTimerWithHistogram() {
        histogramTimer.record(SAMPLE_NS, TimeUnit.NANOSECONDS);
    }

    /** Micrometer lambda variant — some teams prefer this API */
    @Benchmark
    public void micrometerTimerLambda(Blackhole bh) {
        long r = percentilesTimer.record(() -> {
            bh.consume(SAMPLE_NS);
            return SAMPLE_NS;
        });
        bh.consume(r);
    }

    // =========================================================================
    // Main
    // =========================================================================

    public static void main(String[] args) throws RunnerException {
        Options opt = new OptionsBuilder()
            .include(LatencyRecordBenchmark.class.getSimpleName())
            .forks(1)
            .warmupIterations(3)
            .measurementIterations(5)
            .build();
        new Runner(opt).run();
    }
}
