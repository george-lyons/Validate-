package com.insight.benchmark;

import com.insight.metrics.LatencyMetricSet;
import com.insight.metrics.Percentiles;
import io.micrometer.core.instrument.Clock;
import io.micrometer.core.instrument.Timer;
import io.micrometer.prometheusmetrics.PrometheusConfig;
import io.micrometer.prometheusmetrics.PrometheusMeterRegistry;
import io.prometheus.metrics.core.datapoints.DistributionDataPoint;
import io.prometheus.metrics.core.metrics.Histogram;
import io.prometheus.metrics.model.registry.PrometheusRegistry;
import org.HdrHistogram.Recorder;
import org.openjdk.jmh.annotations.Benchmark;
import org.openjdk.jmh.annotations.BenchmarkMode;
import org.openjdk.jmh.annotations.Fork;
import org.openjdk.jmh.annotations.Level;
import org.openjdk.jmh.annotations.Measurement;
import org.openjdk.jmh.annotations.Mode;
import org.openjdk.jmh.annotations.OutputTimeUnit;
import org.openjdk.jmh.annotations.Param;
import org.openjdk.jmh.annotations.Scope;
import org.openjdk.jmh.annotations.Setup;
import org.openjdk.jmh.annotations.State;
import org.openjdk.jmh.annotations.Warmup;

import java.util.concurrent.TimeUnit;

/**
 * Hot-path recording comparison only.
 *
 * We deliberately avoid scrape/export work here and cache any label-bound handle up front,
 * because the question is the strategy-thread cost of recording one latency observation.
 */
@BenchmarkMode(Mode.AverageTime)
@OutputTimeUnit(TimeUnit.NANOSECONDS)
@Warmup(iterations = 5, time = 1, timeUnit = TimeUnit.SECONDS)
@Measurement(iterations = 8, time = 1, timeUnit = TimeUnit.SECONDS)
@Fork(2)
@State(Scope.Thread)
public class LatencyRecordingComparisonBenchmark {

    @Param({"1000"})
    public long valueNs;

    private Recorder hdrRecorder;
    private DistributionDataPoint prometheusHistogram;
    private Timer micrometerTimer;
    private LatencyMetricSet latencyMetricSet;

    @Setup(Level.Trial)
    public void setup() {
        hdrRecorder = new Recorder(TimeUnit.SECONDS.toNanos(10), 3);

        final PrometheusRegistry prometheusRegistry = new PrometheusRegistry();
        prometheusHistogram = Histogram.builder()
                .name("strategy_latency_seconds")
                .help("Strategy-thread latency")
                .classicOnly()
                .classicUpperBounds(
                        1e-6, 2e-6, 5e-6,
                        10e-6, 20e-6, 50e-6,
                        100e-6, 200e-6, 500e-6,
                        1e-3, 2e-3, 5e-3)
                .register(prometheusRegistry);

        final PrometheusMeterRegistry micrometerRegistry =
                new PrometheusMeterRegistry(PrometheusConfig.DEFAULT, new PrometheusRegistry(), Clock.SYSTEM);
        micrometerTimer = Timer.builder("strategy.latency")
                .description("Strategy-thread latency")
                .publishPercentileHistogram()
                .serviceLevelObjectives(
                        java.time.Duration.ofNanos(1_000),
                        java.time.Duration.ofNanos(2_000),
                        java.time.Duration.ofNanos(5_000),
                        java.time.Duration.ofNanos(10_000),
                        java.time.Duration.ofNanos(20_000),
                        java.time.Duration.ofNanos(50_000),
                        java.time.Duration.ofNanos(100_000),
                        java.time.Duration.ofNanos(200_000),
                        java.time.Duration.ofNanos(500_000),
                        java.time.Duration.ofMillis(1),
                        java.time.Duration.ofMillis(2),
                        java.time.Duration.ofMillis(5))
                .register(micrometerRegistry);

        latencyMetricSet = new LatencyMetricSet(
                new io.micrometer.core.instrument.simple.SimpleMeterRegistry(),
                "algo.strategy.latency",
                new String[] {"strategy-0"},
                Percentiles.of(50.0, 95.0, 99.0, 99.9),
                TimeUnit.SECONDS.toNanos(10),
                3);
    }

    @Benchmark
    public void hdrHistogramRecorder_recordValue() {
        hdrRecorder.recordValue(valueNs);
    }

    @Benchmark
    public void hdrHistogramRecorder_recordValueWithExpectedInterval() {
        hdrRecorder.recordValueWithExpectedInterval(valueNs, 500_000L);
    }

    @Benchmark
    public void prometheusClientHistogram_observe() {
        prometheusHistogram.observe(valueNs / 1_000_000_000.0d);
    }

    @Benchmark
    public void micrometerPrometheusTimer_record() {
        micrometerTimer.record(valueNs, TimeUnit.NANOSECONDS);
    }

    @Benchmark
    public void latencyMetricSet_record() {
        latencyMetricSet.record(0, valueNs);
    }

    @Benchmark
    public void latencyMetricSet_recordWithExpectedInterval() {
        latencyMetricSet.recordWithExpectedInterval(0, valueNs, 500_000L);
    }
}
