# latency-metric-set

This zip contains the simplified `LatencyMetricSet` implementation plus a JMH benchmark that compares hot-path recording overhead for four approaches:

- `HdrHistogram Recorder.recordValue(...)`
- `HdrHistogram Recorder.recordValueWithExpectedInterval(...)`
- direct Prometheus Java client `Histogram.observe(...)`
- Micrometer `Timer.record(...)` backed by `PrometheusMeterRegistry`
- `LatencyMetricSet.record(...)`
- `LatencyMetricSet.recordWithExpectedInterval(...)`

## Benchmark class

- `src/jmh/java/com/insight/benchmark/LatencyRecordingComparisonBenchmark.java`

## What it measures

This benchmark is intentionally focused on **strategy-thread recording cost only**.

It does **not** include:

- scrape/export cost
- HTTP endpoint cost
- background publishing cost
- Prometheus server cost

For the Prometheus client benchmark, the histogram is configured with explicit classic buckets.
For the Micrometer benchmark, the timer is backed by `PrometheusMeterRegistry` and configured with percentile histogram publishing plus SLO buckets.

## Build

```bash
mvn -DskipTests clean package
```

This produces:

```bash
target/benchmarks.jar
```

## Run

Run all benchmark methods:

```bash
java -jar target/benchmarks.jar LatencyRecordingComparisonBenchmark
```

Run a specific method:

```bash
java -jar target/benchmarks.jar .*hdrHistogramRecorder.*
java -jar target/benchmarks.jar .*prometheusClientHistogram.*
java -jar target/benchmarks.jar .*micrometerPrometheusTimer.*
java -jar target/benchmarks.jar .*latencyMetricSet.*
```

## Notes

- The benchmark caches metric handles up front to avoid repeatedly resolving labels during the benchmark loop.
- The Prometheus Java client benchmark records seconds because its histogram API is unit-oriented around Prometheus conventions.
- The Micrometer Prometheus registry in `micrometer-registry-prometheus` uses the newer Prometheus Java client line.
